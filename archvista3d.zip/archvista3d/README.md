# ArchVista 3D

Interactive architectural visualisation and property-tour viewer for Blender-exported GLB files.
This repository is **Phase 1 + parts of Phases 3-4** of the spec (see "Status" - read it before judging completeness).

> **Not yet built or run.** The code was written without network access, so `npm install`, `tsc` and `vite build`
> have **not** been executed. Expect a round of type/runtime fixes on first run (`npm run typecheck`).

## Quick start
```bash
npm install            # postinstall copies the Draco decoder into public/draco
npm run dev            # http://localhost:5173   (loads public/models/realtour.glb)
npm run typecheck && npm run build
```
Env: copy `.env.example` -> `.env`. Static hosting: `npm run build` and deploy `dist/` (Netlify, Vercel, Cloudflare Pages...).
The 8 MB GLB is served from `public/models/`; for production move it to private storage + signed URLs (Phase 2).

## What was found in `realtour.glb` (drives the config)
Draco-compressed, 1,028 nodes, 983 meshes, 66 materials, **0 textures**, 14 animations (11 doors, 2 gate leaves,
`Walkthrough_Cam` 304.8 s), 4 cameras, 12 punctual lights, ~1.31 M triangles. It contains five `WEB_*` meshes
(~682 k triangles) that **duplicate** source geometry - the viewer hides them by default (Visibility panel can show them).
Blender light intensities are physical (cd / lux) and are rescaled by `lightScale = 1/683`.
Semantic groups, rooms (from `F_*` floor meshes) and material roles live in `src/config/properties.ts`.

## Status vs. the spec
| Area | State |
|---|---|
| GLB load (Draco), progress, error + retry, resource disposal on switch | **Implemented** |
| Orbit / zoom / pan / reset / fit, 8 computed elevations + Blender-authored cameras, smooth fly-to | **Implemented** |
| Auto-spin (speed, direction, pause-on-touch, resume) | **Implemented** |
| First-person walk (pointer lock, WASD, eye height, collision from wall meshes, floor following) | **Implemented, desktop only, approximate** |
| Guided tour: plays the embedded Blender camera + door animations; timeline, pause/restart, auto-detected stops, speed | **Implemented** (single authored tour; no tour editor) |
| Material editor: pick by click, per-mesh or per-material, colour/roughness/metal/opacity/emissive, palette, finishes, undo/redo | **Implemented** |
| 9 design presets + custom + reset (mapped through material roles) | **Implemented for `realtour` only** |
| Lighting: 12 presets, sun/env/exposure/shadows, interior light group, quality modes | **Implemented** (no bloom / AO / HDRI files yet) |
| Visibility groups (roof, ceiling, furniture, landscape, doors...), cutaway, defurnish | **Implemented** (name-pattern mapped) |
| Rooms list, floor-plan/minimap generated from floor meshes, live camera marker | **Implemented** (areas are bbox estimates) |
| Variants (save/apply/rename/duplicate/delete), before/after toggle, share link | **Implemented - browser localStorage only** |
| Screenshot (1x/2x PNG), hero shot, canvas video recording | **Implemented** |
| Local GLB open + statistics/warnings | **Implemented** (preview only, nothing is uploaded) |
| Responsive layout (drawer/tool strip on small screens) | Implemented; touch joystick for walk mode **not** implemented |
| **Not implemented**: admin dashboard, auth, uploads to storage, chunked upload, property CRUD, hotspots, measurements, tour editor/waypoint capture, inquiries, analytics, embeddable iframe, ortho camera, textures/UV controls, KTX2, SSAO/bloom, server-side Blender render | **Phase 2+** - schema is ready in `supabase/migrations/0001_init.sql` |

See `docs/` for the Blender checklist, admin guide (target workflow), test checklist and known limitations.

## Architecture
```
src/
  config/   properties.ts (semantic mapping per GLB) · lighting.ts · designPresets.ts
  lib/      sceneIndex (read-only scene analysis, chapters) · materialOverrides (non-destructive layer)
            cameraViews · share · recorder · camState
  store/    viewerStore.ts  (zustand: design/undo/variants/tour/mode)   <- single source of truth
  three/    Viewer (Canvas + error boundary) · SceneContents · LightingRig · CameraRig
            TourController · WalkController · CamTracker
  ui/       Chrome (top bar, toolbars, bottom transport, dialogs) · Panels · kit
supabase/migrations/0001_init.sql   full data model + RLS
```
Design rule: the GLB is never modified. Materials are an override layer on top; visibility only toggles mapped groups; saved
variants store `{overrides, lighting, hidden}` JSON, not geometry.
