# Admin guide
**Today (Phase 1):** use *Open GLB* in the top bar to preview and validate a file locally (statistics, warnings, hierarchy, materials).
Nothing is uploaded or stored. To publish a model in this build: put the GLB in `public/models/`, add a `PropertyConfig` in
`src/config/properties.ts` (groups, rooms, material roles, collision/ground patterns), and register it in `PROPERTIES`.

**Target workflow (Phase 2, schema in `supabase/migrations`):** sign in -> Upload GLB (chunked to private storage) -> server validation
(parse, bbox, stats) -> mapping assistant (classify objects, name rooms, material roles) -> calibrate units -> create tours/hotspots
-> preview -> publish -> share/embed link.
