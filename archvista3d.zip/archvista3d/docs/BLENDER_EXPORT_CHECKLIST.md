# Blender -> GLB export checklist
1. Scene units = metres, scale 1.0; apply scale/rotation (Ctrl+A) on meshes. glTF is Y-up: Blender +Y becomes glTF -Z (the exporter handles it).
2. Name objects meaningfully and with stable prefixes (`W_` walls, `F_` floors, `Roof_`, `Door_`...). Names are what the mapping uses.
3. One floor mesh (or a few) per room named `F_<Room>`; the viewer derives room bounds from them.
4. Name materials by role (`wall_in`, `floor_wood`, `roof_tile`...). Shared materials edit together - use *This mesh only* for single overrides.
5. Keep doors/windows/furniture as separate objects; pivot at the hinge for doors; animate with named Actions (`Door_X`).
6. Tour: animate a camera object (e.g. `Walkthrough_Cam`) with position+rotation keys at eye level (1.6 m), no roll; export *Animation -> Always sample*.
7. Lights: export punctual lights (`KHR_lights_punctual`); expect physical units (viewer rescales by 1/683 - tune `lightScale`).
8. Export: glTF Binary (.glb), +Y up, Apply Modifiers, UVs, Normals, Vertex Colors only if used, **Compression (Draco)** on, Cameras on, Lights on, Animation on.
9. Textures: embed, <= 2048 px, power-of-two preferred. Without textures, texture presets are unavailable.
10. **Do not ship merged duplicates** next to the originals (`WEB_*` in the sample doubles the triangle count). Export either editable or merged.
11. Collision / navigation is *not* in a GLB. Walk mode uses wall meshes matched by `collisionPatterns`; author simple invisible collision meshes (`COL_*`) for best results.
