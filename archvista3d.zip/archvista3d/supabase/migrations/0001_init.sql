-- ArchVista 3D - initial schema (Supabase / PostgreSQL).  NOT yet wired into the Phase 1 UI.
-- Apply with:  supabase db push   (or paste into the SQL editor)
create extension if not exists "pgcrypto";

create type app_role as enum ('admin', 'editor');
create type publish_status as enum ('draft', 'published', 'archived');

create table user_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role app_role not null,
  created_at timestamptz not null default now()
);
create or replace function is_staff() returns boolean language sql stable security definer as $$
  select exists (select 1 from user_roles where user_id = auth.uid());
$$;
create or replace function is_admin() returns boolean language sql stable security definer as $$
  select exists (select 1 from user_roles where user_id = auth.uid() and role = 'admin');
$$;

create table properties (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null check (slug ~ '^[a-z0-9-]{3,64}$'),
  name text not null check (char_length(name) between 2 and 160),
  description text, location text, property_type text, category text,
  price numeric(14,2), floors int, rooms int,
  status publish_status not null default 'draft',
  viewer_options jsonb not null default '{"allowMaterials":true,"allowVariants":true,"allowScreenshots":true,"showPrice":false,"allowMeasure":false}',
  branding jsonb not null default '{}',
  cover_path text,
  created_by uuid references auth.users(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index on properties (status);

-- Original GLB files live in PRIVATE object storage (bucket "models"); the DB only stores paths + versions.
create table property_assets (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references properties(id) on delete cascade,
  version int not null default 1,
  storage_path text not null, size_bytes bigint not null check (size_bytes > 0),
  sha256 text, is_current boolean not null default true,
  uploaded_by uuid references auth.users(id), created_at timestamptz not null default now(),
  unique (property_id, version)
);
create unique index one_current_asset on property_assets (property_id) where is_current;

create table model_metadata (
  asset_id uuid primary key references property_assets(id) on delete cascade,
  meshes int, materials int, textures int, triangles bigint, animations int, lights int, cameras int,
  bbox_min real[3], bbox_max real[3], units text default 'm', units_verified boolean default false,
  extensions text[], warnings text[], validated_at timestamptz default now()
);

create table floors (
  id uuid primary key default gen_random_uuid(), property_id uuid not null references properties(id) on delete cascade,
  name text not null, level int not null default 0, elevation_m real, plan_path text,
  plan_scale real, plan_rotation_deg real default 0
);
create table rooms (
  id uuid primary key default gen_random_uuid(), property_id uuid not null references properties(id) on delete cascade,
  floor_id uuid references floors(id) on delete set null, key text not null, label text not null,
  floor_nodes text[] not null default '{}',               -- glTF node names whose bbox defines the room
  area_m2 real, area_source text check (area_source in ('bbox-estimate','manual','survey')),
  spawn jsonb, unique (property_id, key)
);
create table object_mappings (          -- semantic groups & material roles (the "mapping assistant" output)
  id uuid primary key default gen_random_uuid(), property_id uuid not null references properties(id) on delete cascade,
  kind text not null check (kind in ('group','material_role')), key text not null, label text not null,
  patterns text[] not null default '{}', materials text[] not null default '{}', default_hidden boolean default false,
  unique (property_id, kind, key)
);
create table material_library (
  id uuid primary key default gen_random_uuid(), category text not null, name text not null,
  params jsonb not null, texture_path text, license text, is_global boolean default true, property_id uuid references properties(id) on delete cascade
);
create table design_presets (
  id uuid primary key default gen_random_uuid(), name text not null, blurb text, swatch text[], lighting text,
  roles jsonb not null, is_global boolean default true, property_id uuid references properties(id) on delete cascade
);
create table property_variants (        -- never duplicates the GLB: only the override layer
  id uuid primary key default gen_random_uuid(), property_id uuid not null references properties(id) on delete cascade,
  owner_id uuid references auth.users(id), name text not null, shared boolean not null default false,
  design jsonb not null,                -- { overrides, lighting, hidden }
  thumbnail_path text, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index on property_variants (property_id, owner_id);
create table tours (
  id uuid primary key default gen_random_uuid(), property_id uuid not null references properties(id) on delete cascade,
  name text not null, kind text not null check (kind in ('full','exterior','interior','room','custom','orbit','cinematic')),
  published boolean not null default false, source text not null default 'waypoints' check (source in ('waypoints','embedded-clip')),
  clip_name text
);
create table tour_waypoints (
  id uuid primary key default gen_random_uuid(), tour_id uuid not null references tours(id) on delete cascade, position int not null,
  name text not null, pos real[3] not null, target real[3] not null, travel_s real not null default 3, hold_s real not null default 1,
  room_key text, title text, narration text, hotspot_ids uuid[] default '{}', unique (tour_id, position)
);
create table hotspots (
  id uuid primary key default gen_random_uuid(), property_id uuid not null references properties(id) on delete cascade,
  title text not null, body text, category text, pos real[3] not null, room_key text, media jsonb default '[]', link_url text check (link_url ~* '^https?://')
);
create table floor_plans (
  id uuid primary key default gen_random_uuid(), floor_id uuid not null references floors(id) on delete cascade,
  storage_path text not null, mime text not null check (mime in ('image/png','image/jpeg','application/pdf')),
  scale_m_per_px real, rotation_deg real default 0
);
create table property_images (
  id uuid primary key default gen_random_uuid(), property_id uuid not null references properties(id) on delete cascade,
  storage_path text not null, caption text, position int default 0, is_cover boolean default false
);
create table inquiries (
  id uuid primary key default gen_random_uuid(), property_id uuid not null references properties(id) on delete cascade,
  name text not null check (char_length(name) <= 120), email text not null check (email ~* '^[^@\s]+@[^@\s]+$'),
  phone text, message text check (char_length(message) <= 4000), created_at timestamptz not null default now()
);
create table analytics_events (
  id bigint generated always as identity primary key, property_id uuid references properties(id) on delete cascade,
  session_id uuid not null, event text not null check (event in ('view','tour_start','tour_complete','room_view','hotspot_open','inquiry','capture')),
  detail jsonb default '{}', device text, created_at timestamptz not null default now()
);
create index on analytics_events (property_id, event, created_at);

-- ---------------- Row level security ---------------------------------------------------------------
alter table properties enable row level security;           alter table property_assets enable row level security;
alter table model_metadata enable row level security;       alter table floors enable row level security;
alter table rooms enable row level security;                alter table object_mappings enable row level security;
alter table material_library enable row level security;     alter table design_presets enable row level security;
alter table property_variants enable row level security;    alter table tours enable row level security;
alter table tour_waypoints enable row level security;       alter table hotspots enable row level security;
alter table floor_plans enable row level security;          alter table property_images enable row level security;
alter table inquiries enable row level security;            alter table analytics_events enable row level security;
alter table user_roles enable row level security;

create policy "staff manage properties" on properties for all using (is_staff()) with check (is_staff());
create policy "public read published"   on properties for select using (status = 'published');
create policy "admins manage roles"     on user_roles for all using (is_admin()) with check (is_admin());
create policy "read own role"           on user_roles for select using (user_id = auth.uid());

-- child tables of a property: staff full access, public read only when the parent is published
do $$
declare t text;
begin
  foreach t in array array['floors','rooms','object_mappings','hotspots','property_images','tours'] loop
    execute format('create policy "staff %1$s" on %1$I for all using (is_staff()) with check (is_staff())', t);
    execute format('create policy "public %1$s" on %1$I for select using (exists (select 1 from properties p where p.id = %1$I.property_id and p.status = ''published''))', t);
  end loop;
end $$;
create policy "staff waypoints"  on tour_waypoints for all using (is_staff()) with check (is_staff());
create policy "public waypoints" on tour_waypoints for select using (exists (select 1 from tours t join properties p on p.id = t.property_id where t.id = tour_id and t.published and p.status = 'published'));
create policy "staff assets" on property_assets for all using (is_staff()) with check (is_staff());   -- public gets signed URLs from an Edge Function, not table access
create policy "staff meta"   on model_metadata for all using (is_staff()) with check (is_staff());
create policy "staff plans"  on floor_plans for all using (is_staff()) with check (is_staff());
create policy "read libraries" on material_library for select using (true);
create policy "staff libraries" on material_library for all using (is_staff()) with check (is_staff());
create policy "read presets" on design_presets for select using (true);
create policy "staff presets" on design_presets for all using (is_staff()) with check (is_staff());
create policy "own or shared variants" on property_variants for select using (owner_id = auth.uid() or shared or is_staff());
create policy "own variants write" on property_variants for all using (owner_id = auth.uid() or is_staff()) with check (owner_id = auth.uid() or is_staff());
create policy "anyone may inquire" on inquiries for insert with check (exists (select 1 from properties p where p.id = property_id and p.status = 'published'));
create policy "staff read inquiries" on inquiries for select using (is_staff());
create policy "anyone may log events" on analytics_events for insert with check (true);   -- add rate limiting in an Edge Function
create policy "staff read analytics" on analytics_events for select using (is_staff());

-- Storage (private buckets). Create in the dashboard or via SQL:
--   insert into storage.buckets (id, name, public) values ('models','models',false), ('media','media',false);
--   Staff upload policy on storage.objects for bucket 'models'; public viewer receives short-lived signed URLs minted by an Edge Function that checks properties.status = 'published'.
