import { useEffect, useMemo } from 'react'
import { useThree, type ThreeEvent } from '@react-three/fiber'
import { useGLTF } from '@react-three/drei'
import * as THREE from 'three'
import { useViewer } from '../store/viewerStore'
import { buildIndex, detectChapters } from '../lib/sceneIndex'
import { applyOverrides } from '../lib/materialOverrides'
import { standardViews } from '../lib/cameraViews'
import LightingRig from './LightingRig'
import CameraRig from './CameraRig'
import TourController from './TourController'
import WalkController from './WalkController'
import CamTracker from './CamTracker'

useGLTF.setDecoderPath(import.meta.env.VITE_DRACO_PATH ?? '/draco/')

const visibleDeep = (o: THREE.Object3D | null): boolean => {
  for (let n = o; n; n = n.parent) if (!n.visible) return false
  return true
}

export default function SceneContents() {
  const property = useViewer((s) => s.property)
  const gltf = useGLTF(property.modelUrl, true) as unknown as { scene: THREE.Group; animations: THREE.AnimationClip[] }
  const index = useMemo(() => buildIndex(gltf.scene, gltf.animations, property), [gltf, property])
  const { gl, scene, camera } = useThree()

  // publish index, tour chapters, initial framing
  useEffect(() => {
    const st = useViewer.getState()
    st.setIndex(index)
    const { chapters, duration } = property.tourCamera
      ? detectChapters(index.clips, property.tourCamera, index.rooms)
      : { chapters: [], duration: 0 }
    st.setTour({ chapters, duration, time: 0, playing: false, seek: 0 })
    const v = standardViews(index).find((x) => x.id === 'front34')
    if (v) st.flyTo(v.position, v.target, 0.01)
    return () => {
      useViewer.getState().setIndex(null)
      index.root.traverse((o) => {
        const m = o as THREE.Mesh
        if (m.isMesh) {
          m.geometry.dispose()
          ;(Array.isArray(m.material) ? m.material : [m.material]).forEach((x) => x.dispose())
        }
      })
      useGLTF.clear(property.modelUrl)
    }
  }, [index, property])

  // visibility groups (never destructive)
  const hidden = useViewer((s) => s.design.hidden)
  useEffect(() => {
    for (const g of property.groups) for (const o of index.groups[g.id] ?? []) o.visible = !hidden[g.id]
  }, [hidden, index, property])

  // materials (overrides are a layer on top of the untouched GLB materials)
  const overrides = useViewer((s) => s.design.overrides)
  const compare = useViewer((s) => s.compare)
  useEffect(() => { applyOverrides(index, compare ? {} : overrides) }, [overrides, compare, index])

  // shadows
  const shadows = useViewer((s) => s.design.lighting.shadows)
  const quality = useViewer((s) => s.quality)
  useEffect(() => {
    const on = shadows && quality !== 'low'
    for (const m of index.meshes) {
      const glass = /glass|crystal/i.test((m.material as THREE.Material).name ?? '')
      m.castShadow = on && !glass
      m.receiveShadow = on
    }
  }, [shadows, quality, index])

  // selection highlight
  const selected = useViewer((s) => s.selected)
  useEffect(() => {
    if (!selected) return
    const mesh = index.byName.get(selected.mesh)
    if (!mesh) return
    const bh = new THREE.BoxHelper(mesh, 0xd9b36c)
    scene.add(bh)
    return () => { scene.remove(bh); bh.geometry.dispose(); (bh.material as THREE.Material).dispose() }
  }, [selected, index, scene])

  // screenshot API
  useEffect(() => {
    useViewer.getState().setCapture(async (scale) => {
      const prev = gl.getPixelRatio()
      gl.setPixelRatio(prev * scale)
      gl.render(scene, camera)
      const blob = await new Promise<Blob | null>((res) => gl.domElement.toBlob(res, 'image/png'))
      gl.setPixelRatio(prev)
      return blob
    })
    return () => useViewer.getState().setCapture(null)
  }, [gl, scene, camera])

  const onClick = (e: ThreeEvent<MouseEvent>) => {
    const st = useViewer.getState()
    if (!st.materialEdit || e.delta > 4) return
    const hit = e.intersections.find((i) => (i.object as THREE.Mesh).isMesh && visibleDeep(i.object))
    if (!hit) return
    e.stopPropagation()
    const mesh = hit.object as THREE.Mesh
    const mat = Array.isArray(mesh.material) ? mesh.material[0] : mesh.material
    const orig = (mesh.userData.__origMat as THREE.Material | THREE.Material[]) ?? mat
    const origMat = Array.isArray(orig) ? orig[0] : orig
    st.select({ mesh: mesh.name, material: origMat.name || origMat.uuid })
  }
  const onMove = (e: ThreeEvent<PointerEvent>) => {
    if (!useViewer.getState().materialEdit) return
    gl.domElement.style.cursor = e.intersections.some((i) => (i.object as THREE.Mesh).isMesh && visibleDeep(i.object)) ? 'crosshair' : ''
  }

  return (
    <>
      <LightingRig index={index} />
      <primitive object={gltf.scene} onClick={onClick} onPointerMove={onMove} />
      <CameraRig />
      <TourController index={index} />
      <WalkController index={index} />
      <CamTracker />
    </>
  )
}
