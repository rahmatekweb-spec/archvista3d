import { useEffect, useMemo, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { PointerLockControls } from 'three/examples/jsm/controls/PointerLockControls.js'
import { useViewer } from '../store/viewerStore'
import { matches } from '../lib/sceneIndex'
import type { SceneIndex } from '../types'

/** Set by the Rooms panel ("Walk here"); consumed when walk mode starts. */
export const walkSpawn: { value: { x: number; y: number; z: number; yaw: number } | null } = { value: null }

/**
 * First-person controller. Collision is *derived from the model's own wall meshes* (raycasts at
 * knee / waist / head height) and ground-following from floor/paving meshes. This is an automatic
 * approximation: it only protects surfaces matched by `collisionPatterns` / `groundPatterns` in the
 * property config. Furniture is not collidable; doors are walk-through.
 */
export default function WalkController({ index }: { index: SceneIndex }) {
  const { camera, gl } = useThree()
  const mode = useViewer((s) => s.mode)
  const property = useViewer((s) => s.property)
  const pl = useRef<PointerLockControls | null>(null)
  const keys = useRef<Record<string, boolean>>({})
  const vel = useRef(new THREE.Vector3())
  const ray = useMemo(() => new THREE.Raycaster(), [])

  const walls = useMemo(() => {
    const re = property.collisionPatterns.map((p) => new RegExp(p))
    return index.meshes.filter((m) => matches(m.name, re))
  }, [index, property])
  const ground = useMemo(() => {
    const re = property.groundPatterns.map((p) => new RegExp(p))
    return index.meshes.filter((m) => matches(m.name, re))
  }, [index, property])

  useEffect(() => {
    if (mode !== 'walk') return
    const controls = new PointerLockControls(camera, gl.domElement)
    controls.minPolarAngle = Math.PI / 2 - 1.0 // limited pitch, never any roll
    controls.maxPolarAngle = Math.PI / 2 + 1.0
    pl.current = controls
    const eye = useViewer.getState().eyeHeight
    const sp = walkSpawn.value
    const start = property.walkStart
    camera.up.set(0, 1, 0)
    if (sp) {
      camera.position.set(sp.x, sp.y + eye, sp.z)
      camera.rotation.set(0, sp.yaw, 0, 'YXZ')
      walkSpawn.value = null
    } else if (start) {
      camera.position.set(start.position[0], start.position[1] - 1.6 + eye, start.position[2])
      camera.rotation.set(0, THREE.MathUtils.degToRad(start.yawDeg), 0, 'YXZ')
    } else {
      const d = new THREE.Vector3(); camera.getWorldDirection(d)
      camera.rotation.set(0, Math.atan2(-d.x, -d.z), 0, 'YXZ')
    }
    const cam = camera as THREE.PerspectiveCamera
    if (cam.fov !== 60) { cam.fov = 60; cam.updateProjectionMatrix() }
    const lock = () => controls.lock()
    const onLock = () => window.dispatchEvent(new CustomEvent('archvista:walklock', { detail: true }))
    const onUnlock = () => window.dispatchEvent(new CustomEvent('archvista:walklock', { detail: false }))
    const kd = (e: KeyboardEvent) => { if (!(e.target instanceof HTMLInputElement)) keys.current[e.code] = true }
    const ku = (e: KeyboardEvent) => { keys.current[e.code] = false }
    controls.addEventListener('lock', onLock)
    controls.addEventListener('unlock', onUnlock)
    window.addEventListener('archvista:lock', lock)
    window.addEventListener('keydown', kd)
    window.addEventListener('keyup', ku)
    return () => {
      controls.unlock()
      controls.disconnect()
      controls.removeEventListener('lock', onLock)
      controls.removeEventListener('unlock', onUnlock)
      window.removeEventListener('archvista:lock', lock)
      window.removeEventListener('keydown', kd)
      window.removeEventListener('keyup', ku)
      keys.current = {}
      vel.current.set(0, 0, 0)
      pl.current = null
      window.dispatchEvent(new CustomEvent('archvista:walklock', { detail: false }))
    }
  }, [mode, camera, gl, property])

  const dir = useMemo(() => new THREE.Vector3(), [])
  const right = useMemo(() => new THREE.Vector3(), [])
  const want = useMemo(() => new THREE.Vector3(), [])
  const step = useMemo(() => new THREE.Vector3(), [])

  const free = (origin: THREE.Vector3, d: THREE.Vector3, dist: number, floorY: number) => {
    if (d.lengthSq() < 1e-10) return true
    const n = d.clone().normalize()
    for (const h of [0.35, 1.0, 1.55]) {
      ray.set(new THREE.Vector3(origin.x, floorY + h, origin.z), n)
      ray.far = 0.3 + dist
      if (ray.intersectObjects(walls, false).length) return false
    }
    return true
  }

  useFrame((_, dt) => {
    if (mode !== 'walk' || !pl.current?.isLocked) return
    const st = useViewer.getState()
    const k = keys.current
    camera.getWorldDirection(dir)
    dir.y = 0
    dir.normalize()
    right.crossVectors(dir, camera.up).normalize()
    want.set(0, 0, 0)
    if (k.KeyW || k.ArrowUp) want.add(dir)
    if (k.KeyS || k.ArrowDown) want.sub(dir)
    if (k.KeyD || k.ArrowRight) want.add(right)
    if (k.KeyA || k.ArrowLeft) want.sub(right)
    if (want.lengthSq() > 0) want.normalize().multiplyScalar(st.walkSpeed * (k.ShiftLeft ? 1.8 : 1))
    vel.current.lerp(want, 1 - Math.exp(-8 * dt)) // smooth acceleration / deceleration

    // current floor under the feet
    ray.set(new THREE.Vector3(camera.position.x, camera.position.y + 0.3, camera.position.z), new THREE.Vector3(0, -1, 0))
    ray.far = 4
    const gh = ray.intersectObjects(ground, false)[0]
    const floorY = gh ? gh.point.y : camera.position.y - st.eyeHeight

    step.copy(vel.current).multiplyScalar(dt)
    const len = step.length()
    if (len > 1e-6) {
      if (free(camera.position, step, len, floorY)) camera.position.add(step)
      else {
        const sx = new THREE.Vector3(step.x, 0, 0), sz = new THREE.Vector3(0, 0, step.z)
        if (free(camera.position, sx, Math.abs(step.x), floorY)) camera.position.add(sx)
        if (free(camera.position, sz, Math.abs(step.z), floorY)) camera.position.add(sz)
      }
    }
    if (gh) camera.position.y += (gh.point.y + st.eyeHeight - camera.position.y) * (1 - Math.exp(-12 * dt))
  })

  return null
}
