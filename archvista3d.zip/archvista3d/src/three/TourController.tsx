import { useEffect, useMemo, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { useViewer } from '../store/viewerStore'
import type { SceneIndex } from '../types'

/**
 * Plays the animation clips authored in Blender and baked into the GLB:
 *  - the camera path ("Walkthrough_Cam": position + rotation keyframes, eye level, no roll)
 *  - door / gate animations that are keyed on the same timeline
 * A single timeline value drives every clip, so scrubbing / next / previous keep doors and camera in sync.
 */
export default function TourController({ index }: { index: SceneIndex }) {
  const { camera } = useThree()
  const property = useViewer((s) => s.property)
  const mixer = useMemo(() => new THREE.AnimationMixer(index.root), [index])
  const camNode = useMemo(() => (property.tourCamera ? index.byName.get(property.tourCamera) ?? null : null), [index, property])
  const time = useRef(0)
  const uiAcc = useRef(0)
  const lastApplied = useRef(-1)

  useEffect(() => {
    const actions = index.clips.map((c) => {
      const a = mixer.clipAction(c)
      a.setLoop(THREE.LoopOnce, 1)
      a.clampWhenFinished = true
      a.play()
      return a
    })
    mixer.setTime(0)
    return () => { actions.forEach((a) => a.stop()); mixer.stopAllAction(); mixer.uncacheRoot(index.root) }
  }, [mixer, index])

  useFrame((_, dt) => {
    const s = useViewer.getState()
    const t = s.tour
    if (t.seek !== null) {
      time.current = THREE.MathUtils.clamp(t.seek, 0, t.duration)
      useViewer.getState().setTour({ seek: null, time: time.current })
      lastApplied.current = -1
    }
    if (s.mode === 'tour' && t.playing && t.duration > 0) {
      time.current = Math.min(t.duration, time.current + dt * t.speed)
      if (time.current >= t.duration) useViewer.getState().setTour({ playing: false })
    }
    if (time.current !== lastApplied.current && t.duration > 0) {
      mixer.setTime(time.current)
      lastApplied.current = time.current
    }
    if (s.mode === 'tour' && camNode) {
      camNode.updateWorldMatrix(true, false)
      camNode.matrixWorld.decompose(camera.position, camera.quaternion, camera.scale)
      camera.scale.set(1, 1, 1)
      const pc = camNode as THREE.PerspectiveCamera
      const cam = camera as THREE.PerspectiveCamera
      if (pc.isPerspectiveCamera && Math.abs(cam.fov - pc.fov) > 1e-3) { cam.fov = pc.fov; cam.updateProjectionMatrix() }
    }
    uiAcc.current += dt
    if (uiAcc.current > 0.1 && t.playing) { uiAcc.current = 0; useViewer.getState().setTour({ time: time.current }) }
  })
  return null
}
