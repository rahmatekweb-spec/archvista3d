import { useEffect, useMemo } from 'react'
import { useThree } from '@react-three/fiber'
import { Sky } from '@react-three/drei'
import * as THREE from 'three'
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js'
import { useViewer } from '../store/viewerStore'
import { DEFAULT_LIGHTING } from '../config/lighting'
import type { SceneIndex } from '../types'

export default function LightingRig({ index }: { index: SceneIndex }) {
  const { gl, scene } = useThree()
  const property = useViewer((s) => s.property)
  const quality = useViewer((s) => s.quality)
  const compare = useViewer((s) => s.compare)
  const designL = useViewer((s) => s.design.lighting)
  const L = compare ? DEFAULT_LIGHTING : designL

  const sun = useMemo(() => new THREE.DirectionalLight(), [])
  const center = useMemo(() => index.houseBox.getCenter(new THREE.Vector3()), [index])

  // procedural IBL (no HDR download needed)
  useEffect(() => {
    const pm = new THREE.PMREMGenerator(gl)
    const room = new RoomEnvironment()
    const rt = pm.fromScene(room, 0.04)
    scene.environment = rt.texture
    return () => { scene.environment = null; rt.dispose(); pm.dispose() }
  }, [gl, scene])

  const sunVec = useMemo(() => {
    const el = THREE.MathUtils.degToRad(L.sunElevation)
    const az = THREE.MathUtils.degToRad(L.sunAzimuth)
    return new THREE.Vector3(Math.cos(el) * Math.sin(az), Math.sin(el), Math.cos(el) * Math.cos(az))
  }, [L.sunElevation, L.sunAzimuth])

  useEffect(() => {
    gl.toneMapping = THREE.ACESFilmicToneMapping
    gl.toneMappingExposure = L.exposure
    scene.environmentIntensity = L.envIntensity
    scene.environmentRotation.y = THREE.MathUtils.degToRad(L.envRotation)
    scene.background = L.sky ? null : new THREE.Color(L.background)
    sun.color.set(L.sunColor)
    sun.intensity = L.sunElevation < -1 ? 0 : L.sunIntensity
    sun.position.copy(center).addScaledVector(sunVec, 60)
    sun.target.position.copy(center)
    sun.target.updateMatrixWorld()
    const size = quality === 'high' ? 4096 : quality === 'balanced' ? 2048 : 1024
    sun.castShadow = L.shadows && quality !== 'low'
    sun.shadow.mapSize.set(size, size)
    const cam = sun.shadow.camera
    cam.left = -32; cam.right = 32; cam.top = 32; cam.bottom = -32; cam.near = 1; cam.far = 160
    cam.updateProjectionMatrix()
    sun.shadow.bias = -0.0004
    sun.shadow.normalBias = 0.04
    sun.shadow.radius = quality === 'high' ? 3 : 2
    if (sun.shadow.map) { sun.shadow.map.dispose(); sun.shadow.map = null as never }
  }, [L, gl, scene, sun, sunVec, center, quality])

  // Blender exports physical units -> rescale imported point lights, keep them as the "interior light group".
  useEffect(() => {
    for (const l of index.lights) {
      if (l.name === 'Sun' || (l as THREE.DirectionalLight).isDirectionalLight) { l.visible = false; continue }
      if (l.userData.__i0 === undefined) l.userData.__i0 = l.intensity
      l.intensity = l.userData.__i0 * property.lightScale * L.interiorIntensity
      l.visible = L.interiorOn
      l.castShadow = false
    }
  }, [index, property, L.interiorOn, L.interiorIntensity])

  return (
    <>
      <primitive object={sun} />
      <primitive object={sun.target} />
      <hemisphereLight args={['#dfe9f5', '#3b3a36', 0.25]} />
      {L.sky && <Sky distance={450000} sunPosition={sunVec.clone().multiplyScalar(1000)} turbidity={6} rayleigh={L.sunElevation < 15 ? 3 : 1.2} mieCoefficient={0.005} mieDirectionalG={0.8} />}
    </>
  )
}
