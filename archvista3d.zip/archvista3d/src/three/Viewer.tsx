import { Canvas } from '@react-three/fiber'
import { Component, Suspense, type ReactNode } from 'react'
import * as THREE from 'three'
import { useViewer } from '../store/viewerStore'
import SceneContents from './SceneContents'

class Boundary extends Component<{ children: ReactNode; onRetry: () => void }, { err: Error | null }> {
  state = { err: null as Error | null }
  static getDerivedStateFromError(err: Error) { return { err } }
  render() {
    if (!this.state.err) return this.props.children
    return (
      <div className="absolute inset-0 grid place-items-center p-6">
        <div className="glass max-w-md rounded-2xl p-6 text-center">
          <h2 className="mb-2 text-lg font-semibold">The model could not be loaded</h2>
          <p className="mb-4 text-sm text-white/70">{this.state.err.message}</p>
          <p className="mb-4 text-xs text-white/50">Check that the GLB exists, is valid, and (if Draco-compressed) that the decoder at VITE_DRACO_PATH is reachable.</p>
          <button className="btn-accent" onClick={() => { this.setState({ err: null }); this.props.onRetry() }}>Retry</button>
        </div>
      </div>
    )
  }
}

export default function Viewer({ reloadKey, onRetry }: { reloadKey: number; onRetry: () => void }) {
  const quality = useViewer((s) => s.quality)
  const dpr: [number, number] = quality === 'low' ? [1, 1] : quality === 'balanced' ? [1, 1.5] : [1, 2]
  return (
    <Boundary onRetry={onRetry}>
      <Canvas
        key={reloadKey}
        shadows={quality !== 'low'}
        dpr={dpr}
        camera={{ fov: 50, near: 0.05, far: 800, position: [20, 12, -30] }}
        gl={{ antialias: true, powerPreference: 'high-performance', toneMapping: THREE.ACESFilmicToneMapping, outputColorSpace: THREE.SRGBColorSpace }}
        onPointerMissed={() => useViewer.getState().select(null)}
      >
        <Suspense fallback={null}>
          <SceneContents />
        </Suspense>
      </Canvas>
    </Boundary>
  )
}
