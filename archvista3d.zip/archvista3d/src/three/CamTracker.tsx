import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { camState } from '../lib/camState'

const v = new THREE.Vector3()
export default function CamTracker() {
  useFrame(({ camera }) => {
    camera.getWorldDirection(v)
    camState.x = camera.position.x; camState.y = camera.position.y; camState.z = camera.position.z
    camState.dx = v.x; camState.dz = v.z
  })
  return null
}
