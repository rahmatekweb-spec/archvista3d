import { useEffect, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import * as THREE from 'three'
import type { OrbitControls as OrbitControlsImpl } from 'three/examples/jsm/controls/OrbitControls.js'
import { useViewer } from '../store/viewerStore'

const ease = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2)

export default function CameraRig() {
  const controls = useRef<OrbitControlsImpl>(null)
  const { camera } = useThree()
  const mode = useViewer((s) => s.mode)
  const fly = useViewer((s) => s.fly)
  const spin = useViewer((s) => s.spin)
  const prevMode = useRef(mode)
  const st = useRef<{ t: number; dur: number; p0: THREE.Vector3; p1: THREE.Vector3; t0: THREE.Vector3; t1: THREE.Vector3; f0: number; f1: number } | null>(null)

  useEffect(() => {
    if (!fly || !controls.current) return
    const cam = camera as THREE.PerspectiveCamera
    st.current = {
      t: 0, dur: Math.max(0.01, fly.duration),
      p0: camera.position.clone(), p1: new THREE.Vector3(...fly.position),
      t0: controls.current.target.clone(), t1: new THREE.Vector3(...fly.target),
      f0: cam.fov, f1: fly.fov ?? 50,
    }
  }, [fly?.id])

  // when leaving walk/tour, orbit around a point in front of the camera (no jump, no roll)
  useEffect(() => {
    if (mode === 'orbit' && prevMode.current !== 'orbit' && controls.current) {
      const dir = new THREE.Vector3(); camera.getWorldDirection(dir)
      controls.current.target.copy(camera.position).addScaledVector(dir, 6)
      camera.up.set(0, 1, 0)
      controls.current.update()
    }
    prevMode.current = mode
  }, [mode, camera])

  useFrame((_, dt) => {
    const c = controls.current
    const s = st.current
    if (!c || !s) return
    s.t = Math.min(1, s.t + dt / s.dur)
    const e = ease(s.t)
    camera.position.lerpVectors(s.p0, s.p1, e)
    c.target.lerpVectors(s.t0, s.t1, e)
    const cam = camera as THREE.PerspectiveCamera
    if (Math.abs(cam.fov - (s.f0 + (s.f1 - s.f0) * e)) > 1e-3) { cam.fov = s.f0 + (s.f1 - s.f0) * e; cam.updateProjectionMatrix() }
    c.update()
    if (s.t >= 1) st.current = null
  })

  return (
    <OrbitControls
      ref={controls as never}
      makeDefault
      enabled={mode === 'orbit'}
      enableDamping
      dampingFactor={0.08}
      maxPolarAngle={Math.PI * 0.495}
      minDistance={0.4}
      maxDistance={160}
      autoRotate={spin.enabled && !spin.paused}
      autoRotateSpeed={spin.speed * spin.dir * 2}
      onStart={() => { const s = useViewer.getState().spin; if (s.enabled && !s.paused) useViewer.getState().setSpin({ paused: true }) }}
    />
  )
}
