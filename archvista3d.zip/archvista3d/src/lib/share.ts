import type { DesignState } from '../types'

export const encodeDesign = (d: DesignState) => btoa(unescape(encodeURIComponent(JSON.stringify(d))))
export function decodeDesign(s: string): DesignState | null {
  try { return JSON.parse(decodeURIComponent(escape(atob(s)))) as DesignState } catch { return null }
}
export function shareUrl(propertyId: string, d: DesignState) {
  const u = new URL(window.location.href)
  u.search = ''
  u.hash = ''
  u.searchParams.set('p', propertyId)
  u.hash = 'd=' + encodeDesign(d)
  return u.toString()
}
