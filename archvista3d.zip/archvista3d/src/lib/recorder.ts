const TYPES = ['video/mp4;codecs=avc1', 'video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm']
export const supportedVideoTypes = () => (typeof MediaRecorder === 'undefined' ? [] : TYPES.filter((t) => MediaRecorder.isTypeSupported(t)))

export class CanvasRecorder {
  private rec: MediaRecorder | null = null
  private chunks: BlobPart[] = []
  start(canvas: HTMLCanvasElement, mime: string, fps: number, bitrate = 12_000_000) {
    const stream = canvas.captureStream(fps)
    this.chunks = []
    this.rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: bitrate })
    this.rec.ondataavailable = (e) => e.data.size && this.chunks.push(e.data)
    this.rec.start(250)
  }
  stop(): Promise<Blob> {
    return new Promise((resolve) => {
      if (!this.rec) return resolve(new Blob())
      const type = this.rec.mimeType
      this.rec.onstop = () => resolve(new Blob(this.chunks, { type }))
      this.rec.stop()
    })
  }
}
export function download(blob: Blob, filename: string) {
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = filename
  a.click()
  setTimeout(() => URL.revokeObjectURL(a.href), 4000)
}
