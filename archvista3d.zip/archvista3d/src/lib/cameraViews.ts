import * as THREE from 'three'
import type { SceneIndex } from '../types'

export interface View { id: string; label: string; position: [number, number, number]; target: [number, number, number] }

/** Elevations are computed from the house's real bounding box (not hard-coded coordinates). */
export function standardViews(index: SceneIndex): View[] {
  const b = index.houseBox
  const c = b.getCenter(new THREE.Vector3())
  const s = b.getSize(new THREE.Vector3())
  const r = Math.max(s.x, s.z)
  const d = r * 1.45
  const h = c.y + 1.3
  const t: [number, number, number] = [c.x, c.y + 0.2, c.z]
  const v = (id: string, label: string, p: [number, number, number]): View => ({ id, label, position: p, target: t })
  // In this export the entrance porch (Blender +Y) is on the glTF -Z side, so "front" = min.z.
  return [
    v('front', 'Front elevation', [c.x, h, b.min.z - d]),
    v('rear', 'Rear elevation', [c.x, h, b.max.z + d]),
    v('left', 'Left elevation', [b.min.x - d, h, c.z]),
    v('right', 'Right elevation', [b.max.x + d, h, c.z]),
    v('front34', 'Front ¾', [b.max.x + d * 0.75, h + r * 0.2, b.min.z - d * 0.75]),
    v('rear34', 'Rear ¾', [b.min.x - d * 0.75, h + r * 0.2, b.max.z + d * 0.75]),
    v('bird', "Bird's-eye", [c.x + r * 0.5, c.y + r * 1.2, c.z - r * 0.9]),
    { id: 'top', label: 'Top view', position: [c.x, c.y + r * 1.9, c.z + 0.001], target: [c.x, c.y, c.z] },
  ]
}

/** Views from the cameras baked into the GLB (e.g. Cam_Front / Cam_Aerial) - authored in Blender. */
export function authoredViews(index: SceneIndex): (View & { fov: number })[] {
  const out: (View & { fov: number })[] = []
  for (const cam of index.cameras) {
    if (!cam.name || cam.name === 'Walkthrough_Cam') continue
    cam.updateWorldMatrix(true, false)
    const p = new THREE.Vector3().setFromMatrixPosition(cam.matrixWorld)
    const dir = new THREE.Vector3(0, 0, -1).transformDirection(cam.matrixWorld)
    const t = p.clone().addScaledVector(dir, 20)
    out.push({ id: 'cam:' + cam.name, label: cam.name.replace(/^Cam_/, 'Blender cam: '), position: p.toArray() as [number, number, number], target: t.toArray() as [number, number, number], fov: (cam as THREE.PerspectiveCamera).fov ?? 50 })
  }
  return out
}

/** Interior view: eye-level camera in a room corner looking across the room (auto-framed). */
export function roomView(room: SceneIndex['rooms'][number], eye = 1.6): View {
  const [x0, , z0] = room.min
  const [x1, , z1] = room.max
  const w = x1 - x0, d = z1 - z0
  // stand at the corner nearest the min-corner, look to the opposite corner
  const px = x0 + w * 0.18, pz = z0 + d * 0.18
  const tx = x1 - w * 0.2, tz = z1 - d * 0.2
  return { id: 'room:' + room.id, label: room.label, position: [px, room.floorY + eye, pz], target: [tx, room.floorY + eye * 0.85, tz] }
}
