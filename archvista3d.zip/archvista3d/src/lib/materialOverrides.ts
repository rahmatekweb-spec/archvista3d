import * as THREE from 'three'
import type { MatOverride, Overrides, SceneIndex } from '../types'

type Std = THREE.MeshStandardMaterial
const isStd = (m: unknown): m is Std => !!(m as Std)?.isMeshStandardMaterial

interface Snap {
  color: THREE.Color
  roughness: number
  metalness: number
  opacity: number
  transparent: boolean
  emissive: THREE.Color
  emissiveIntensity: number
}
const snaps = new WeakMap<THREE.Material, Snap>()

function snapshot(m: Std) {
  if (snaps.has(m)) return
  snaps.set(m, {
    color: m.color.clone(), roughness: m.roughness, metalness: m.metalness, opacity: m.opacity,
    transparent: m.transparent, emissive: m.emissive.clone(), emissiveIntensity: m.emissiveIntensity,
  })
}
function restore(m: Std) {
  const s = snaps.get(m)
  if (!s) return
  m.color.copy(s.color); m.roughness = s.roughness; m.metalness = s.metalness; m.opacity = s.opacity
  m.transparent = s.transparent; m.emissive.copy(s.emissive); m.emissiveIntensity = s.emissiveIntensity
  m.needsUpdate = true
}
function patch(m: Std, o: MatOverride) {
  if (o.color !== undefined) m.color.set(o.color)
  if (o.roughness !== undefined) m.roughness = o.roughness
  if (o.metalness !== undefined) m.metalness = o.metalness
  if (o.opacity !== undefined) { m.opacity = o.opacity; m.transparent = o.opacity < 1 || (snaps.get(m)?.transparent ?? false) }
  if (o.emissive !== undefined) m.emissive.set(o.emissive)
  if (o.emissiveIntensity !== undefined) m.emissiveIntensity = o.emissiveIntensity
  m.needsUpdate = true
}

/** Read the *original* values of a material (for the editor's initial control state). */
export function originalOf(m: THREE.Material): MatOverride {
  if (!isStd(m)) return {}
  snapshot(m)
  const s = snaps.get(m)!
  return { color: '#' + s.color.getHexString(), roughness: s.roughness, metalness: s.metalness, opacity: s.opacity, emissiveIntensity: s.emissiveIntensity, emissive: '#' + s.emissive.getHexString() }
}

/**
 * Non-destructive: the loaded GLB / its source file are never modified.
 *  - `mat:name`  edits the shared material (all meshes that use it)
 *  - `mesh:name` clones the material for that one mesh, so siblings stay untouched
 */
export function applyOverrides(index: SceneIndex, overrides: Overrides) {
  for (const mesh of index.meshes) {
    const orig = mesh.userData.__origMat as THREE.Material | THREE.Material[] | undefined
    if (orig && mesh.material !== orig) {
      if (mesh.userData.__clone) (mesh.material as THREE.Material).dispose()
      mesh.material = orig
      mesh.userData.__clone = false
    }
  }
  for (const m of index.materials.values()) if (isStd(m)) { snapshot(m); restore(m) }

  for (const [k, o] of Object.entries(overrides)) {
    if (!k.startsWith('mat:')) continue
    const m = index.materials.get(k.slice(4))
    if (isStd(m)) patch(m, o)
  }
  for (const [k, o] of Object.entries(overrides)) {
    if (!k.startsWith('mesh:')) continue
    const mesh = index.byName.get(k.slice(5)) as THREE.Mesh | undefined
    const base = mesh?.userData.__origMat as THREE.Material | undefined
    if (!mesh || !isStd(base)) continue
    const clone = base.clone() as Std
    patch(clone, o)
    mesh.material = clone
    mesh.userData.__clone = true
  }
}
