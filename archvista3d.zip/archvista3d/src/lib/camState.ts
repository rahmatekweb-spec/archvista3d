/** Mutable camera snapshot for lightweight consumers (floor-plan marker) - avoids React re-renders per frame. */
export const camState = { x: 0, y: 0, z: 0, dx: 0, dz: -1 }
