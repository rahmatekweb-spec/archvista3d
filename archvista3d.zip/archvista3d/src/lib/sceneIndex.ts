import * as THREE from 'three'
import type { Chapter, PropertyConfig, RoomInfo, SceneIndex, SceneStats } from '../types'

const rx = (patterns: string[]) => patterns.map((p) => new RegExp(p))
export const matches = (name: string, res: RegExp[]) => res.some((r) => r.test(name))

const TEX_KEYS = ['map', 'normalMap', 'roughnessMap', 'metalnessMap', 'aoMap', 'emissiveMap', 'alphaMap', 'bumpMap'] as const

/** Walk the loaded glTF scene once and build everything the UI needs. Pure read-only (no geometry changes). */
export function buildIndex(
  root: THREE.Object3D,
  clips: THREE.AnimationClip[],
  cfg: PropertyConfig,
): SceneIndex {
  const meshes: THREE.Mesh[] = []
  const byName = new Map<string, THREE.Object3D>()
  const materials = new Map<string, THREE.Material>()
  const materialUsers = new Map<string, THREE.Mesh[]>()
  const lights: THREE.Light[] = []
  const cameras: THREE.Camera[] = []
  const textures = new Set<THREE.Texture>()
  let triangles = 0
  let noUV = 0

  root.updateMatrixWorld(true)
  root.traverse((o) => {
    if (o.name && !byName.has(o.name)) byName.set(o.name, o)
    if ((o as THREE.Light).isLight) lights.push(o as THREE.Light)
    if ((o as THREE.Camera).isCamera) cameras.push(o as THREE.Camera)
    const mesh = o as THREE.Mesh
    if (!mesh.isMesh) return
    meshes.push(mesh)
    const geo = mesh.geometry
    triangles += geo.index ? geo.index.count / 3 : (geo.attributes.position?.count ?? 0) / 3
    if (!geo.attributes.uv) noUV++
    const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material]
    mesh.userData.__origMat = mesh.material
    for (const m of mats) {
      const key = m.name || m.uuid
      if (!materials.has(key)) materials.set(key, m)
      const arr = materialUsers.get(key) ?? []
      arr.push(mesh)
      materialUsers.set(key, arr)
      for (const k of TEX_KEYS) {
        const t = (m as unknown as Record<string, THREE.Texture | null>)[k]
        if (t) textures.add(t)
      }
    }
  })

  // semantic groups
  const groups: Record<string, THREE.Object3D[]> = {}
  for (const g of cfg.groups) {
    const res = rx(g.patterns)
    groups[g.id] = []
    root.traverse((o) => {
      if (o !== root && o.name && matches(o.name, res)) groups[g.id].push(o)
    })
  }

  // house bounds (fit / elevations); falls back to the whole scene
  const houseBox = new THREE.Box3()
  if (cfg.houseNodePatterns.length) {
    const res = rx(cfg.houseNodePatterns)
    root.traverse((o) => {
      if ((o as THREE.Mesh).isMesh && matches(o.name, res)) houseBox.expandByObject(o)
    })
  }
  if (houseBox.isEmpty()) houseBox.setFromObject(root)

  // rooms from real floor meshes
  const rooms: RoomInfo[] = []
  for (const r of cfg.rooms) {
    const b = new THREE.Box3()
    for (const n of r.floorNodes) {
      const o = byName.get(n)
      if (o) b.expandByObject(o)
    }
    if (b.isEmpty()) continue
    const c = b.getCenter(new THREE.Vector3())
    rooms.push({
      id: r.id,
      label: r.label,
      min: b.min.toArray() as [number, number, number],
      max: b.max.toArray() as [number, number, number],
      center: c.toArray() as [number, number, number],
      floorY: b.max.y,
      area: Math.round((b.max.x - b.min.x) * (b.max.z - b.min.z) * 10) / 10,
    })
  }

  const whole = new THREE.Box3().setFromObject(root)
  const size = whole.getSize(new THREE.Vector3())
  const warnings: string[] = []
  if (triangles > 1_000_000) warnings.push(`High triangle count (${Math.round(triangles / 1000)}k). Low quality mode recommended on mobile.`)
  if (meshes.length > 800) warnings.push(`${meshes.length} separate meshes -> many draw calls. Merge static geometry (see Blender export checklist).`)
  if (textures.size === 0) warnings.push('No textures embedded: surfaces use flat colours. Texture presets are unavailable for this model.')
  if (noUV > 0) warnings.push(`${noUV} meshes have no UV coordinates (texture assignment would not work on them).`)
  if (groups['webmerged']?.length) {
    warnings.push('The file contains WEB_* merged meshes that duplicate source geometry. They are hidden by default to avoid double rendering.')
  }
  if (!cfg.unitsVerified) warnings.push('Model units are assumed to be metres (glTF default) but have not been calibrated.')

  const stats: SceneStats = {
    meshes: meshes.length,
    materials: materials.size,
    textures: textures.size,
    triangles: Math.round(triangles),
    lights: lights.length,
    cameras: cameras.length,
    meshesWithoutUV: noUV,
    size: size.toArray() as [number, number, number],
    clips: clips.map((c) => ({ name: c.name, duration: c.duration })),
    warnings,
  }

  return { root, meshes, byName, materials, materialUsers, groups, lights, cameras, clips, houseBox, rooms, stats }
}

/** Find "holds" in the embedded camera path (camera nearly stationary) and use them as tour chapters. */
export function detectChapters(clips: THREE.AnimationClip[], cameraName: string, rooms: RoomInfo[]): { chapters: Chapter[]; duration: number } {
  const duration = clips.reduce((m, c) => Math.max(m, c.duration), 0)
  const clip = clips.find((c) => c.tracks.some((t) => t.name.startsWith(cameraName + '.position')))
  const track = clip?.tracks.find((t) => t.name.startsWith(cameraName + '.position')) as THREE.VectorKeyframeTrack | undefined
  if (!clip || !track) return { chapters: [], duration }
  const interp = track.createInterpolant()
  const out = new Float32Array(3)
  const step = 0.25
  const pos: THREE.Vector3[] = []
  for (let t = 0; t <= clip.duration; t += step) {
    interp.evaluate(t)
    const r = interp.resultBuffer as Float32Array
    out.set(r)
    pos.push(new THREE.Vector3(out[0], out[1], out[2]))
  }
  const chapters: Chapter[] = [{ id: 'c0', time: 0, label: 'Start' }]
  const MIN_HOLD = 6 // samples (1.5 s)
  let run = 0
  for (let i = 1; i < pos.length; i++) {
    const speed = pos[i].distanceTo(pos[i - 1]) / step
    if (speed < 0.05) run++
    else {
      if (run >= MIN_HOLD) {
        const t0 = (i - run) * step
        if (t0 - chapters[chapters.length - 1].time > 4) chapters.push({ id: 'c' + chapters.length, time: t0, label: '' })
      }
      run = 0
    }
  }
  // label by the room containing the camera at that moment
  chapters.forEach((c, i) => {
    interp.evaluate(c.time)
    const r = interp.resultBuffer as Float32Array
    const room = rooms.find((rm) => r[0] >= rm.min[0] && r[0] <= rm.max[0] && r[2] >= rm.min[2] && r[2] <= rm.max[2])
    c.label = (i === 0 ? 'Start - ' : '') + (room ? room.label : 'Exterior') + ` (${fmtTime(c.time)})`
  })
  return { chapters, duration }
}

export const fmtTime = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`
