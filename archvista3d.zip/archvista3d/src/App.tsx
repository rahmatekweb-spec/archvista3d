import { useEffect, useState } from 'react'
import Viewer from './three/Viewer'
import { BottomBar, LeftToolbar, LoadingOverlay, MiniMap, MobileTools, PresetsDialog, RightPanel, Toast, TopBar, WalkOverlay } from './ui/Chrome'
import { useViewer } from './store/viewerStore'
import { PROPERTIES } from './config/properties'
import { decodeDesign } from './lib/share'

export default function App() {
  const [key, setKey] = useState(0)
  const property = useViewer((s) => s.property)

  // open a shared link:  ?p=<propertyId>#d=<encoded design>
  useEffect(() => {
    const id = new URLSearchParams(location.search).get('p')
    const p = PROPERTIES.find((x) => x.id === id)
    if (p && p.id !== useViewer.getState().property.id) useViewer.getState().setProperty(p)
    const m = location.hash.match(/d=(.+)$/)
    const d = m ? decodeDesign(m[1]) : null
    if (d) useViewer.getState().commit(d)
  }, [])

  // global shortcuts: Ctrl/Cmd+Z / Shift+Z, Space = play/pause tour
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLSelectElement) return
      const s = useViewer.getState()
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? s.redo() : s.undo() }
      if (e.code === 'Space' && s.mode === 'tour') { e.preventDefault(); s.setTour({ playing: !s.tour.playing }) }
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [])

  return (
    <div className="relative h-full w-full overflow-hidden bg-ink">
      <Viewer key={property.id + property.modelUrl} reloadKey={key} onRetry={() => setKey((k) => k + 1)} />
      <TopBar onLoaded={() => setKey((k) => k + 1)} />
      <LeftToolbar />
      <MobileTools />
      <RightPanel />
      <MiniMap />
      <BottomBar />
      <WalkOverlay />
      <PresetsDialog />
      <Toast />
      <LoadingOverlay />
    </div>
  )
}
