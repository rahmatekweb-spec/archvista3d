import type { MatOverride } from '../types'

/** A design preset = role -> override (roles are mapped to real material names per property). */
export interface DesignPreset {
  id: string
  label: string
  blurb: string
  swatch: string[]
  lighting: string
  roles: Record<string, MatOverride>
}

const m = (color: string, roughness?: number, metalness?: number): MatOverride => ({ color, roughness, metalness })

export const DESIGN_PRESETS: DesignPreset[] = [
  { id: 'minimalist', label: 'Modern Minimalist', blurb: 'Pure white walls, pale oak, charcoal frames.', swatch: ['#f3f2ee', '#c9b79c', '#2b2d30'], lighting: 'neutral',
    roles: { wallInterior: m('#f4f3ef', 0.92), wallExterior: m('#ecebe6', 0.9), trim: m('#ffffff', 0.5), floorMain: m('#c9b79c', 0.5), roof: m('#2f3236', 0.6), frames: m('#1b1c1e', 0.4, 0.5), cabinets: m('#f2f2f0', 0.35), counter: m('#ededed', 0.2), sofa: m('#b8b8b6', 0.9), curtains: m('#f1efe9', 0.95) } },
  { id: 'luxury', label: 'Contemporary Luxury', blurb: 'Greige walls, dark walnut, brass accents.', swatch: ['#cfc6b8', '#4a3326', '#c99a4b'], lighting: 'showroom',
    roles: { wallInterior: m('#cfc7ba', 0.85), wallExterior: m('#d6cfc3', 0.88), floorMain: m('#4b3425', 0.28), roof: m('#262626', 0.5), frames: m('#14110e', 0.35, 0.7), cabinets: m('#2b2e33', 0.3), counter: m('#1d1d1f', 0.12), sofa: m('#3d3a37', 0.85), accent: m('#c99a4b', 0.3, 0.9), curtains: m('#b7ab98', 0.95) } },
  { id: 'scandi', label: 'Scandinavian Natural', blurb: 'Soft white, light birch, muted sage.', swatch: ['#f1efe8', '#d9c3a0', '#9db09a'], lighting: 'overcast',
    roles: { wallInterior: m('#f1efe8', 0.95), wallExterior: m('#e6e4dc', 0.92), floorMain: m('#d9c3a0', 0.55), roof: m('#5d5f60', 0.7), frames: m('#8b8d8c', 0.5, 0.2), cabinets: m('#e8e6df', 0.45), sofa: m('#9db09a', 0.95), curtains: m('#eee9df', 0.95), accent: m('#7e9aa6', 0.6) } },
  { id: 'earthy', label: 'Warm Earthy', blurb: 'Terracotta, clay and sun-baked sand.', swatch: ['#d9b894', '#a4593a', '#6b4a33'], lighting: 'golden',
    roles: { wallInterior: m('#e2c9a8', 0.9), wallExterior: m('#d9b894', 0.92), trim: m('#f2e6d3', 0.6), floorMain: m('#7a4d32', 0.4), roof: m('#7b3b27', 0.65), frames: m('#3a2518', 0.4), cabinets: m('#8c5a3c', 0.5), sofa: m('#a4593a', 0.9), curtains: m('#e9d8bc', 0.95) } },
  { id: 'industrial', label: 'Industrial Modern', blurb: 'Raw concrete greys with black steel.', swatch: ['#8d8f90', '#3b3d3f', '#111214'], lighting: 'cinematic',
    roles: { wallInterior: m('#8f9192', 0.95), wallExterior: m('#7c7e7f', 0.95), trim: m('#bfc1c2', 0.7), floorMain: m('#5a4a3c', 0.5), roof: m('#1c1d1f', 0.55, 0.3), frames: m('#0e0f10', 0.35, 0.8), cabinets: m('#2c2e30', 0.4, 0.3), counter: m('#2a2a2a', 0.25), sofa: m('#4b4d50', 0.9) } },
  { id: 'classic', label: 'Classic Elegant', blurb: 'Ivory walls, rich mahogany, antique gold.', swatch: ['#efe6d3', '#5c2f1f', '#b8913f'], lighting: 'warm',
    roles: { wallInterior: m('#efe6d3', 0.88), wallExterior: m('#e8dcc2', 0.9), trim: m('#fbf7ee', 0.45), floorMain: m('#5c2f1f', 0.3), roof: m('#3b2a22', 0.6), frames: m('#2a1b12', 0.35), cabinets: m('#f0e8d6', 0.4), sofa: m('#7d2f35', 0.9), accent: m('#b8913f', 0.3, 0.9), curtains: m('#d8c7a1', 0.95) } },
  { id: 'mediterranean', label: 'Mediterranean', blurb: 'Whitewash, terracotta tiles, azure accents.', swatch: ['#f7f3ea', '#b5593a', '#2f6fa3'], lighting: 'daylight',
    roles: { wallInterior: m('#f7f3ea', 0.92), wallExterior: m('#fbf8f0', 0.95), floorMain: m('#b5764f', 0.55), roof: m('#b5593a', 0.7), frames: m('#2f6fa3', 0.45), doors: m('#2f6fa3', 0.4), cabinets: m('#2f6fa3', 0.4), sofa: m('#e2d6bd', 0.95), accent: m('#2f6fa3', 0.5) } },
  { id: 'tropical', label: 'Tropical Contemporary', blurb: 'Teak, deep green accents, airy neutrals.', swatch: ['#efeadc', '#8a5a34', '#2f5d46'], lighting: 'daylight',
    roles: { wallInterior: m('#efeadc', 0.9), wallExterior: m('#e7dfc9', 0.9), floorMain: m('#8a5a34', 0.42), roof: m('#4a4237', 0.65), frames: m('#2b2a26', 0.4), cabinets: m('#2f5d46', 0.4), sofa: m('#d8cfb8', 0.95), accent: m('#2f5d46', 0.55), curtains: m('#f2eee2', 0.95) } },
  { id: 'monochrome', label: 'Monochrome', blurb: 'Black, white and grey only.', swatch: ['#ffffff', '#808080', '#101010'], lighting: 'neutral',
    roles: { wallInterior: m('#fafafa', 0.9), wallExterior: m('#e9e9e9', 0.9), trim: m('#ffffff', 0.5), floorMain: m('#4a4a4a', 0.35), roof: m('#151515', 0.5), frames: m('#0a0a0a', 0.4, 0.5), cabinets: m('#1a1a1a', 0.3), counter: m('#f0f0f0', 0.15), sofa: m('#808080', 0.9), accent: m('#101010', 0.5), curtains: m('#d9d9d9', 0.95) } },
]
export const COLOR_PALETTE: { label: string; colors: string[] }[] = [
  { label: 'Whites', colors: ['#ffffff', '#f6f4ee', '#efe9dc'] },
  { label: 'Neutrals', colors: ['#e3dccd', '#cfc6b8', '#bdbdbb', '#8f9192', '#4a4d50', '#202124'] },
  { label: 'Earth', colors: ['#d9b894', '#b5764f', '#a4593a', '#7a4d32', '#4b3425'] },
  { label: 'Timber', colors: ['#d9c3a0', '#c9a874', '#9a6b3f', '#6b4429', '#3d2618'] },
  { label: 'Accents', colors: ['#2f6fa3', '#2f5d46', '#7d2f35', '#c99a4b', '#7e9aa6'] },
]
export const FINISH_PRESETS: { id: string; label: string; o: { roughness: number; metalness: number } }[] = [
  { id: 'matte', label: 'Matte', o: { roughness: 0.95, metalness: 0 } },
  { id: 'satin', label: 'Satin', o: { roughness: 0.55, metalness: 0 } },
  { id: 'gloss', label: 'Gloss', o: { roughness: 0.12, metalness: 0 } },
  { id: 'polished', label: 'Polished stone', o: { roughness: 0.06, metalness: 0 } },
  { id: 'brushed', label: 'Brushed metal', o: { roughness: 0.38, metalness: 1 } },
  { id: 'mirror', label: 'Mirror metal', o: { roughness: 0.04, metalness: 1 } },
]
