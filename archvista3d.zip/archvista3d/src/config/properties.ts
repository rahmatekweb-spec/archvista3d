import type { PropertyConfig } from '../types'

/**
 * Semantic mapping for `public/models/realtour.glb`.
 * Everything below was derived from the real node / material names in that file
 * (glTF Y-up, metres). Nothing here invents geometry: rooms come from the F_* floor meshes.
 */
export const REALTOUR: PropertyConfig = {
  id: 'realtour',
  name: 'Hip-Roof Bungalow',
  tagline: '3 bed · 4 bath · portico · pool-ready garden',
  description:
    'Single-storey bungalow exported from Blender: open-plan living/dining/kitchen, master suite with bath, two further bedrooms with ensuites, guest washroom, car porch and a walled garden with gate.',
  modelUrl: '/models/realtour.glb',
  unitsVerified: false,
  houseNodePatterns: ['^W_', '^F_', '^Roof_', '^Ceiling_Slab', '^Portico', '^CarPorch', '^KPorch'],
  groups: [
    { id: 'roof', label: 'Roof & eaves', patterns: ['^Roof_', '^Eave_', '^Soffit_', '^Band_'], toggle: true },
    { id: 'ceiling', label: 'Ceilings & trays', patterns: ['^Ceiling_Slab', '^Tray_'], toggle: true },
    {
      id: 'furniture',
      label: 'Furniture & decor',
      toggle: true,
      patterns: [
        '^B\\d_', '^Master_', '^Sofa', '^Coffee', '^DChair', '^Dining', '^Island', '^Stool', '^Fridge',
        '^TV', '^Console', '^Rug', '^Curtain', '^Art', '^Plant', '^Lamp', '^FloorLamp', '^SideTable',
        '^Fruit', '^Pend', '^Chand', '^Wardrobe', '^Pantry', '^Shelf', '^Runner', '^Tufts',
      ],
    },
    { id: 'landscape', label: 'Landscaping', toggle: true, patterns: ['^Tree', '^FarTree', '^Palm', '^ShrubS', '^Bougain', '^Planter', '^Lawn'] },
    { id: 'doors', label: 'Doors', toggle: true, patterns: ['^Door_'] },
    { id: 'windows', label: 'Windows', toggle: true, patterns: ['^Win_'] },
    { id: 'gate', label: 'Gate & boundary', toggle: true, patterns: ['^Gate', '^BW_'] },
    { id: 'walls', label: 'Walls', patterns: ['^W_'] },
    { id: 'floors', label: 'Floors', patterns: ['^F_'] },
    // The file contains 5 pre-merged "WEB_*" meshes (~680k tris) that duplicate source geometry.
    { id: 'webmerged', label: 'WEB_* merged duplicates', patterns: ['^WEB_'], defaultHidden: true },
  ],
  rooms: [
    { id: 'hall', label: 'Entrance Hall', floorNodes: ['F_Hall'] },
    { id: 'living', label: 'Living & Dining', floorNodes: ['F_LivDin'] },
    { id: 'kitchen', label: 'Kitchen', floorNodes: ['F_Kitchen'] },
    { id: 'store', label: 'Store', floorNodes: ['F_Store'] },
    { id: 'corridor', label: 'Corridor', floorNodes: ['F_Corr2', 'F_Corr3'] },
    { id: 'master', label: 'Master Bedroom', floorNodes: ['F_Master'] },
    { id: 'mbath', label: 'Master Bath', floorNodes: ['F_MBath'] },
    { id: 'bed2', label: 'Bedroom 2', floorNodes: ['F_B2a', 'F_B2b'] },
    { id: 'ens2', label: 'Ensuite 2', floorNodes: ['F_Ens2'] },
    { id: 'bed3', label: 'Bedroom 3', floorNodes: ['F_B3a', 'F_B3b'] },
    { id: 'ens3', label: 'Ensuite 3', floorNodes: ['F_Ens3'] },
    { id: 'guest', label: 'Guest Washroom', floorNodes: ['F_Guest'] },
  ],
  roles: [
    { id: 'wallInterior', label: 'Interior walls', materials: ['wall_in'] },
    { id: 'wallExterior', label: 'Exterior walls', materials: ['wall_ext'] },
    { id: 'trim', label: 'Trim & columns', materials: ['trim_white'] },
    { id: 'floorMain', label: 'Timber floors', materials: ['floor_wood'] },
    { id: 'floorTile', label: 'Tile floors', materials: ['floor_tile', 'floor_tile_big'] },
    { id: 'marble', label: 'Marble', materials: ['marble', 'marble_dark'] },
    { id: 'roof', label: 'Roof tiles', materials: ['roof_tile'] },
    { id: 'frames', label: 'Window frames', materials: ['alu_dark'] },
    { id: 'doors', label: 'Doors', materials: ['door'] },
    { id: 'cabinets', label: 'Kitchen cabinets', materials: ['cab_white', 'cab_wood'] },
    { id: 'counter', label: 'Countertops', materials: ['quartz'] },
    { id: 'sofa', label: 'Sofas', materials: ['sofa', 'sofa_dark'] },
    { id: 'accent', label: 'Accent', materials: ['accent_teal'] },
    { id: 'curtains', label: 'Curtains', materials: ['drape'] },
    { id: 'plinth', label: 'Plinth', materials: ['plinth_paint'] },
    { id: 'paving', label: 'Paving', materials: ['paving', 'pavers', 'porch_tile'] },
  ],
  collisionPatterns: ['^W_', '^BW_', '^Col_', '^Pilaster', '^GatePier'],
  groundPatterns: ['^F_', '^Portico', '^CarPorch', '^KPorch', '^Path_', '^Apron', '^Plinth', '^Driveway', '^Lawn', '^Sidewalk'],
  tourCamera: 'Walkthrough_Cam',
  // Blender exports physical units (cd / lux); three.js expects ~1/683 of that at exposure 1.
  lightScale: 1 / 683,
  walkStart: { position: [-8, 1.6, -5], yawDeg: -90 },
  facts: { Style: 'Contemporary hip roof', Bedrooms: '3', Bathrooms: '4', 'Model units': 'metres (unverified)' },
}

/** Fallback for any other GLB (no semantic mapping yet -> mapping assistant is Phase 2/3). */
export const genericConfig = (name: string, url: string): PropertyConfig => ({
  id: 'local',
  name,
  tagline: 'Local file preview',
  description: 'A locally opened GLB. No semantic mapping is configured, so mapped features (rooms, groups, presets) are disabled.',
  modelUrl: url,
  unitsVerified: false,
  houseNodePatterns: [],
  groups: [],
  rooms: [],
  roles: [],
  collisionPatterns: [],
  groundPatterns: [],
  lightScale: 1 / 683,
  facts: {},
})

export const PROPERTIES: PropertyConfig[] = [REALTOUR]
