import type { LightingState } from '../types'

const base: LightingState = {
  preset: 'daylight', exposure: 1.0, sunIntensity: 3.2, sunAzimuth: 215, sunElevation: 48, sunColor: '#fff4e0',
  envIntensity: 0.9, envRotation: 0, sky: true, background: '#9ec3e6', interiorOn: true, interiorIntensity: 1, shadows: true,
}
const P = (o: Partial<LightingState>): LightingState => ({ ...base, ...o })

export const LIGHTING_PRESETS: Record<string, { label: string; state: LightingState }> = {
  daylight: { label: 'Bright Daylight', state: P({}) },
  overcast: { label: 'Soft Overcast', state: P({ preset: 'overcast', sunIntensity: 0.6, envIntensity: 1.3, sunColor: '#e8eef5', background: '#b9c3cc', exposure: 1.05 }) },
  golden: { label: 'Golden Hour', state: P({ preset: 'golden', sunElevation: 12, sunAzimuth: 240, sunIntensity: 3.4, sunColor: '#ffb76b', envIntensity: 0.6, background: '#f1b98a', exposure: 0.95 }) },
  sunrise: { label: 'Sunrise', state: P({ preset: 'sunrise', sunElevation: 8, sunAzimuth: 100, sunIntensity: 2.6, sunColor: '#ffc28a', envIntensity: 0.55, background: '#f6c9a6' }) },
  sunset: { label: 'Sunset', state: P({ preset: 'sunset', sunElevation: 4, sunAzimuth: 255, sunIntensity: 2.4, sunColor: '#ff8a4c', envIntensity: 0.45, background: '#e58a6a', exposure: 0.9, interiorIntensity: 1.3 }) },
  blue: { label: 'Blue Hour', state: P({ preset: 'blue', sunElevation: -2, sunIntensity: 0.15, sunColor: '#8fb0ff', envIntensity: 0.35, sky: false, background: '#1d2a44', interiorIntensity: 1.8, exposure: 1.0 }) },
  night: { label: 'Night Exterior', state: P({ preset: 'night', sunElevation: -10, sunIntensity: 0.05, sunColor: '#6f86c8', envIntensity: 0.15, sky: false, background: '#070b14', interiorIntensity: 2.2, exposure: 1.1 }) },
  warm: { label: 'Warm Interior', state: P({ preset: 'warm', sunIntensity: 1.4, envIntensity: 0.6, interiorIntensity: 1.8, background: '#cfd8e0', exposure: 1.05 }) },
  cool: { label: 'Cool Interior', state: P({ preset: 'cool', sunIntensity: 2.4, sunColor: '#e4efff', envIntensity: 1.0, interiorIntensity: 0.6, background: '#a8c8e8' }) },
  showroom: { label: 'Luxury Showroom', state: P({ preset: 'showroom', sunIntensity: 1.0, envIntensity: 0.8, interiorIntensity: 2.4, sky: false, background: '#14161a', exposure: 1.1 }) },
  cinematic: { label: 'Dramatic Cinematic', state: P({ preset: 'cinematic', sunElevation: 20, sunAzimuth: 300, sunIntensity: 4.2, envIntensity: 0.3, sky: false, background: '#10151c', exposure: 0.85, interiorIntensity: 1.2 }) },
  neutral: { label: 'Neutral Presentation', state: P({ preset: 'neutral', sunIntensity: 1.6, envIntensity: 1.1, sky: false, background: '#d8d9db', exposure: 1.0 }) },
}
export const DEFAULT_LIGHTING = LIGHTING_PRESETS.daylight.state
