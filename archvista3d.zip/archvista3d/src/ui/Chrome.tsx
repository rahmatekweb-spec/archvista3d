import { useEffect, useRef, useState } from 'react'
import { useProgress } from '@react-three/drei'
import {
  Box, Camera, ChevronLeft, ChevronRight, Compass, Download, Eye, Footprints, Home, Info, Layers, Lightbulb, Map as MapIcon, Maximize, Orbit, Palette,
  Pause, Play, Redo2, RotateCcw, Save, Settings, Share2, SkipBack, Sparkles, Undo2, Upload, Video, Wand2,
} from 'lucide-react'
import { useViewer, type Mode, type PanelId } from '../store/viewerStore'
import { PROPERTIES, genericConfig } from '../config/properties'
import { DESIGN_PRESETS } from '../config/designPresets'
import { shareUrl } from '../lib/share'
import { fmtTime } from '../lib/sceneIndex'
import {
  CapturePanel, DiagnosticsPanel, HierarchyPanel, LightingPanel, MaterialsPanel, OverviewPanel, PlanPanel, RoomsPanel, VariantsPanel, ViewsPanel, VisibilityPanel,
} from './Panels'

/* ------------------------------------------------------------------ Top bar */
export function TopBar({ onLoaded }: { onLoaded: () => void }) {
  const s = useViewer()
  const file = useRef<HTMLInputElement>(null)
  const [settings, setSettings] = useState(false)
  const modes: { id: Mode; label: string; icon: JSX.Element }[] = [
    { id: 'orbit', label: 'Orbit', icon: <Orbit size={15} /> },
    { id: 'walk', label: 'Walk', icon: <Footprints size={15} /> },
    { id: 'tour', label: 'Tour', icon: <Video size={15} /> },
  ]
  const toggleFs = () => (document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen())
  const openFile = (f: File | undefined) => {
    if (!f) return
    if (!/\.(glb|gltf)$/i.test(f.name)) return s.toast('Please choose a .glb or .gltf file.')
    if (f.size > 500 * 1024 * 1024) return s.toast('File exceeds the 500 MB local preview limit.')
    s.setProperty(genericConfig(f.name.replace(/\.(glb|gltf)$/i, ''), URL.createObjectURL(f)))
    onLoaded()
  }
  return (
    <header className="pointer-events-none absolute inset-x-0 top-0 z-20 flex flex-wrap items-center gap-2 p-3">
      <div className="glass pointer-events-auto flex items-center gap-3 rounded-2xl px-3 py-2">
        <span className="flex items-center gap-1.5 font-semibold tracking-tight"><Box size={18} className="text-accent" />ArchVista<span className="text-accent">3D</span></span>
        <select className="max-w-[180px] truncate rounded-lg border border-white/10 bg-black/30 px-2 py-1 text-sm" aria-label="Property" value={s.property.id}
          onChange={(e) => { const p = PROPERTIES.find((x) => x.id === e.target.value); if (p) { s.setProperty(p); onLoaded() } }}>
          {PROPERTIES.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          {s.property.id === 'local' && <option value="local">{s.property.name} (local)</option>}
        </select>
        <button className="btn px-2 py-1" title="Open a local GLB (preview & validation only)" onClick={() => file.current?.click()}><Upload size={14} /><span className="hidden lg:inline">Open GLB</span></button>
        <input ref={file} type="file" accept=".glb,.gltf,model/gltf-binary" className="hidden" onChange={(e) => { openFile(e.target.files?.[0]); e.target.value = '' }} />
      </div>
      <div className="glass pointer-events-auto flex rounded-2xl p-1" role="tablist" aria-label="Viewer mode">
        {modes.map((m) => <button key={m.id} role="tab" aria-selected={s.mode === m.id} className={`btn px-3 py-1.5 ${s.mode === m.id ? 'btn-on' : ''}`} onClick={() => s.setMode(m.id)}>{m.icon}<span className="hidden sm:inline">{m.label}</span></button>)}
      </div>
      <button className="btn-accent pointer-events-auto rounded-2xl" onClick={() => s.setPresetsOpen(true)}><Wand2 size={15} /> Design presets</button>
      <div className="glass pointer-events-auto ml-auto flex items-center gap-0.5 rounded-2xl p-1">
        <button className="btn px-2" aria-label="Undo" disabled={!s.past.length} onClick={s.undo}><Undo2 size={16} /></button>
        <button className="btn px-2" aria-label="Redo" disabled={!s.future.length} onClick={s.redo}><Redo2 size={16} /></button>
        <button className="btn px-2" aria-label="Save design as variant" title="Save design" onClick={() => { s.saveVariant(''); }}><Save size={16} /></button>
        <button className="btn px-2" aria-label="Share" onClick={() => navigator.clipboard.writeText(shareUrl(s.property.id, s.design)).then(() => s.toast('Share link copied.'))}><Share2 size={16} /></button>
        <button className="btn px-2" aria-label="Fullscreen" onClick={toggleFs}><Maximize size={16} /></button>
        <div className="relative">
          <button className="btn px-2" aria-label="Settings" onClick={() => setSettings((v) => !v)}><Settings size={16} /></button>
          {settings && (
            <div className="glass absolute right-0 top-11 w-56 rounded-xl p-3 text-sm">
              <div className="label mb-1">Render quality</div>
              <div className="grid grid-cols-3 gap-1">{(['low', 'balanced', 'high'] as const).map((q) => <button key={q} className={`btn px-1 py-1 capitalize ${s.quality === q ? 'btn-on' : ''}`} onClick={() => s.setQuality(q)}>{q}</button>)}</div>
              <p className="mt-2 text-xs text-white/45">Low: no shadows, 1× pixel ratio. Balanced: 2K shadows. High: 4K soft shadows, up to 2× pixels.</p>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}

/* ------------------------------------------------------------------ Left toolbar */
const TOOLS: { id: Exclude<PanelId, null>; label: string; icon: JSX.Element }[] = [
  { id: 'overview', label: 'Overview', icon: <Home size={18} /> },
  { id: 'views', label: 'Views & movement', icon: <Compass size={18} /> },
  { id: 'rooms', label: 'Rooms', icon: <Layers size={18} /> },
  { id: 'materials', label: 'Materials', icon: <Palette size={18} /> },
  { id: 'lighting', label: 'Lighting', icon: <Lightbulb size={18} /> },
  { id: 'visibility', label: 'Visibility', icon: <Eye size={18} /> },
  { id: 'plan', label: 'Floor plan', icon: <MapIcon size={18} /> },
  { id: 'hierarchy', label: 'Hierarchy', icon: <Sparkles size={18} /> },
  { id: 'variants', label: 'Variants', icon: <Save size={18} /> },
  { id: 'capture', label: 'Capture', icon: <Camera size={18} /> },
  { id: 'diagnostics', label: 'Diagnostics', icon: <Info size={18} /> },
]
export function LeftToolbar() {
  const { panel, setPanel } = useViewer()
  return (
    <nav aria-label="Tools" className="glass pointer-events-auto absolute bottom-24 left-3 top-20 z-20 hidden w-12 flex-col items-center gap-1 overflow-auto rounded-2xl py-2 md:flex">
      {TOOLS.map((t) => <button key={t.id} title={t.label} aria-label={t.label} className={`btn h-10 w-10 p-0 ${panel === t.id ? 'btn-on' : ''}`} onClick={() => setPanel(t.id)}>{t.icon}</button>)}
    </nav>
  )
}
/** Mobile: horizontally scrolling tool strip above the bottom bar */
export function MobileTools() {
  const { panel, setPanel } = useViewer()
  return (
    <nav aria-label="Tools" className="glass pointer-events-auto absolute inset-x-2 bottom-[5.5rem] z-20 flex gap-1 overflow-x-auto rounded-2xl p-1 md:hidden">
      {TOOLS.map((t) => <button key={t.id} aria-label={t.label} className={`btn shrink-0 px-3 ${panel === t.id ? 'btn-on' : ''}`} onClick={() => setPanel(t.id)}>{t.icon}</button>)}
    </nav>
  )
}

/* ------------------------------------------------------------------ Right panel (drawer on mobile) */
export function RightPanel() {
  const { panel, setPanel } = useViewer()
  if (!panel) return null
  const title = TOOLS.find((t) => t.id === panel)?.label
  return (
    <aside className="glass pointer-events-auto absolute inset-x-2 bottom-36 z-30 flex max-h-[48vh] flex-col overflow-hidden rounded-2xl md:inset-x-auto md:bottom-24 md:right-3 md:top-20 md:max-h-none md:w-[340px]" aria-label={title}>
      <div className="flex items-center justify-between border-b border-white/10 px-4 py-2.5"><h2 className="text-sm font-medium">{title}</h2><button className="btn px-2 py-1" aria-label="Close panel" onClick={() => setPanel(panel)}>✕</button></div>
      <div className="flex-1 overflow-y-auto">
        {panel === 'overview' && <OverviewPanel />}
        {panel === 'views' && <ViewsPanel />}
        {panel === 'rooms' && <RoomsPanel />}
        {panel === 'materials' && <MaterialsPanel />}
        {panel === 'lighting' && <LightingPanel />}
        {panel === 'visibility' && <VisibilityPanel />}
        {panel === 'plan' && <PlanPanel />}
        {panel === 'hierarchy' && <HierarchyPanel />}
        {panel === 'variants' && <VariantsPanel />}
        {panel === 'capture' && <CapturePanel />}
        {panel === 'diagnostics' && <DiagnosticsPanel />}
      </div>
    </aside>
  )
}

/* ------------------------------------------------------------------ Bottom bar (tour transport) */
export function BottomBar() {
  const { tour, setTour, mode, setMode, capture, toast } = useViewer()
  const hasTour = tour.duration > 0
  const chapters = tour.chapters
  const cur = [...chapters].reverse().find((c) => c.time <= tour.time + 0.05)
  const play = () => { if (!hasTour) return; if (mode !== 'tour') setMode('tour'); if (tour.time >= tour.duration - 0.1) setTour({ seek: 0, time: 0 }); setTour({ playing: true }) }
  const jump = (dir: 1 | -1) => {
    if (!chapters.length) return
    const t = dir === 1 ? chapters.find((c) => c.time > tour.time + 0.5) : [...chapters].reverse().find((c) => c.time < tour.time - 1.5)
    if (mode !== 'tour') setMode('tour')
    setTour({ seek: t ? t.time : dir === 1 ? tour.duration : 0 })
  }
  const snap = async () => {
    const b = await capture?.(1)
    if (!b) return toast('Capture unavailable.')
    const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = `archvista-${Date.now()}.png`; a.click()
  }
  return (
    <footer className="glass pointer-events-auto absolute inset-x-2 bottom-3 z-20 flex flex-wrap items-center gap-2 rounded-2xl px-3 py-2 md:inset-x-auto md:left-1/2 md:w-[min(900px,calc(100%-27rem))] md:-translate-x-1/2">
      {hasTour ? (
        <>
          <button className="btn px-2" aria-label="Restart" onClick={() => { setMode('tour'); setTour({ seek: 0, time: 0, playing: true }) }}><RotateCcw size={16} /></button>
          <button className="btn px-2" aria-label="Previous stop" onClick={() => jump(-1)}><ChevronLeft size={18} /></button>
          {tour.playing && mode === 'tour'
            ? <button className="btn-accent h-9 w-9 rounded-full p-0" aria-label="Pause" onClick={() => setTour({ playing: false })}><Pause size={16} /></button>
            : <button className="btn-accent h-9 w-9 rounded-full p-0" aria-label="Play walkthrough" onClick={play}><Play size={16} /></button>}
          <button className="btn px-2" aria-label="Next stop" onClick={() => jump(1)}><ChevronRight size={18} /></button>
          <div className="min-w-[140px] flex-1">
            <div className="flex justify-between text-[11px] text-white/55"><span className="truncate">{cur?.label ?? 'Guided tour'}</span><span className="tabular-nums">{fmtTime(tour.time)} / {fmtTime(tour.duration)}</span></div>
            <input type="range" className="w-full accent-[#d9b36c]" min={0} max={tour.duration} step={0.1} value={tour.time} aria-label="Tour timeline"
              onChange={(e) => { if (mode !== 'tour') setMode('tour'); setTour({ seek: parseFloat(e.target.value), time: parseFloat(e.target.value) }) }} />
          </div>
          <select className="rounded-lg border border-white/10 bg-black/30 px-1.5 py-1 text-xs" aria-label="Tour speed" value={tour.speed} onChange={(e) => setTour({ speed: +e.target.value })}>
            {[0.5, 1, 1.5, 2, 4].map((v) => <option key={v} value={v}>{v}×</option>)}
          </select>
        </>
      ) : <span className="px-2 text-sm text-white/60">No embedded walkthrough in this model - use Orbit or Walk.</span>}
      <button className="btn px-2" aria-label="Snapshot" onClick={snap}><Camera size={16} /></button>
      <span className="hidden text-xs text-white/40 lg:block">{mode === 'tour' ? 'Tour' : mode === 'walk' ? 'Walk' : 'Orbit'}</span>
    </footer>
  )
}

/* ------------------------------------------------------------------ Mini floor plan (desktop) */
export function MiniMap() {
  const [open, setOpen] = useState(true)
  const { panel } = useViewer()
  if (panel === 'plan') return null
  return (
    <div className="glass pointer-events-auto absolute bottom-24 left-[4.5rem] z-10 hidden w-56 overflow-hidden rounded-2xl md:block">
      <button className="flex w-full items-center justify-between px-3 py-1.5 text-xs text-white/60" onClick={() => setOpen((o) => !o)}>Mini-map<span>{open ? '–' : '+'}</span></button>
      {open && <PlanPanel compact />}
    </div>
  )
}

/* ------------------------------------------------------------------ Overlays */
export function LoadingOverlay() {
  const { active, progress, loaded, total } = useProgress()
  const index = useViewer((s) => s.index)
  if (index && !active) return null
  return (
    <div className="absolute inset-0 z-40 grid place-items-center bg-ink/80 backdrop-blur-sm">
      <div className="glass w-72 rounded-2xl p-5 text-center">
        <div className="mb-3 text-sm text-white/80">Loading model…</div>
        <div className="h-1.5 overflow-hidden rounded-full bg-white/10"><div className="h-full bg-accent transition-[width]" style={{ width: `${progress}%` }} /></div>
        <div className="mt-2 text-xs tabular-nums text-white/50">{progress.toFixed(0)}%{total ? ` · ${(loaded / 1e6).toFixed(1)} / ${(total / 1e6).toFixed(1)} MB` : ''}</div>
      </div>
    </div>
  )
}

export function WalkOverlay() {
  const mode = useViewer((s) => s.mode)
  const setMode = useViewer((s) => s.setMode)
  const [locked, setLocked] = useState(false)
  const touch = typeof window !== 'undefined' && matchMedia('(pointer: coarse)').matches
  useEffect(() => {
    const h = (e: Event) => setLocked((e as CustomEvent<boolean>).detail)
    window.addEventListener('archvista:walklock', h)
    return () => window.removeEventListener('archvista:walklock', h)
  }, [])
  if (mode !== 'walk' || locked) return null
  return (
    <div className="absolute inset-0 z-30 grid place-items-center bg-black/40">
      <div className="glass max-w-sm rounded-2xl p-6 text-center">
        <Footprints className="mx-auto mb-2 text-accent" />
        <h2 className="mb-1 text-lg font-semibold">First-person walk</h2>
        {touch
          ? <p className="mb-4 text-sm text-white/70">Walk mode needs a keyboard and mouse (pointer lock). A touch joystick is not implemented yet - use Orbit or the guided Tour on this device.</p>
          : <p className="mb-4 text-sm text-white/70"><b>W A S D</b> / arrows to move · mouse to look · <b>Shift</b> to run · <b>Esc</b> to release the mouse.<br />Collision uses the model's wall meshes (automatic approximation).</p>}
        <div className="flex justify-center gap-2">
          {!touch && <button className="btn-accent" onClick={() => window.dispatchEvent(new Event('archvista:lock'))}>Click to enter</button>}
          <button className="btn border border-white/10" onClick={() => setMode('orbit')}>Back to orbit</button>
        </div>
      </div>
    </div>
  )
}

export function Toast() {
  const n = useViewer((s) => s.notice)
  if (!n) return null
  return <div role="status" className="glass pointer-events-none absolute left-1/2 top-20 z-50 -translate-x-1/2 rounded-xl px-4 py-2 text-sm">{n}</div>
}

/* ------------------------------------------------------------------ Design presets dialog */
export function PresetsDialog() {
  const { presetsOpen, setPresetsOpen, applyPreset, property, design } = useViewer()
  if (!presetsOpen) return null
  const dirty = Object.keys(design.overrides).length > 0
  const apply = (id: string) => {
    if (dirty && !confirm('Applying a preset replaces your current unsaved material edits. Continue?')) return
    applyPreset(id)
    setPresetsOpen(false)
  }
  return (
    <div className="absolute inset-0 z-50 grid place-items-center bg-black/60 p-4" role="dialog" aria-modal="true" aria-label="Design presets" onClick={() => setPresetsOpen(false)}>
      <div className="glass max-h-[85vh] w-full max-w-4xl overflow-auto rounded-3xl p-5" onClick={(e) => e.stopPropagation()}>
        <div className="mb-3 flex items-center justify-between"><h2 className="text-lg font-semibold">Design presets</h2><button className="btn" onClick={() => setPresetsOpen(false)}>Close</button></div>
        {!property.roles.length && <p className="mb-3 rounded-lg bg-amber-500/10 p-3 text-sm text-amber-200">This property has no material roles mapped, so presets cannot be applied safely. Add roles to its config (mapping assistant: Phase 2).</p>}
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
          {DESIGN_PRESETS.map((p) => (
            <button key={p.id} className="rounded-2xl border border-white/10 p-3 text-left transition hover:border-accent hover:bg-white/5 disabled:opacity-40" disabled={!property.roles.length} onClick={() => apply(p.id)}>
              <div className="mb-2 flex h-10 overflow-hidden rounded-lg">{p.swatch.map((c) => <div key={c} className="flex-1" style={{ background: c }} />)}</div>
              <div className="font-medium">{p.label}</div><div className="text-xs text-white/55">{p.blurb}</div>
            </button>
          ))}
          <button className="rounded-2xl border border-dashed border-white/20 p-3 text-left hover:border-accent" onClick={() => { setPresetsOpen(false); useViewer.getState().setPanel('materials') }}>
            <div className="mb-2 grid h-10 place-items-center rounded-lg bg-white/5"><Palette /></div><div className="font-medium">Custom design</div><div className="text-xs text-white/55">Keeps your current settings; opens the material editor.</div>
          </button>
        </div>
        <div className="mt-4 flex justify-end"><button className="btn border border-white/10" onClick={() => { if (!dirty || confirm('Discard all unsaved changes and restore the original?')) { useViewer.getState().resetDesign(); setPresetsOpen(false) } }}><RotateCcw size={14} /> Reset to original</button></div>
      </div>
    </div>
  )
}
