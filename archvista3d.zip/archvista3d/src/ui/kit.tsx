import type { ReactNode } from 'react'
import { useViewer } from '../store/viewerStore'

export const beginEdit = () => useViewer.getState().commit((d) => d) // push an undo step once per gesture
export const liveDesign = (fn: (d: ReturnType<typeof useViewer.getState>['design']) => ReturnType<typeof useViewer.getState>['design']) =>
  useViewer.setState((s) => ({ design: fn(s.design) }))

export function Slider(p: { label: string; value: number; min: number; max: number; step?: number; onChange: (v: number) => void; onStart?: () => void; fmt?: (v: number) => string }) {
  return (
    <label className="block py-1.5">
      <div className="mb-1 flex justify-between text-xs text-white/70"><span>{p.label}</span><span className="tabular-nums text-white/50">{p.fmt ? p.fmt(p.value) : p.value.toFixed(2)}</span></div>
      <input type="range" className="w-full accent-[#d9b36c]" min={p.min} max={p.max} step={p.step ?? 0.01} value={p.value}
        onPointerDown={p.onStart} onChange={(e) => p.onChange(parseFloat(e.target.value))} aria-label={p.label} />
    </label>
  )
}
export function Toggle(p: { label: string; checked: boolean; onChange: (b: boolean) => void; hint?: string }) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-3 py-1.5 text-sm" title={p.hint}>
      <span className="text-white/80">{p.label}</span>
      <input type="checkbox" className="h-4 w-4 accent-[#d9b36c]" checked={p.checked} onChange={(e) => p.onChange(e.target.checked)} />
    </label>
  )
}
export function Section({ title, children, right }: { title: string; children: ReactNode; right?: ReactNode }) {
  return (
    <section className="border-b border-white/5 px-4 py-3 last:border-0">
      <div className="mb-2 flex items-center justify-between"><h3 className="label">{title}</h3>{right}</div>
      {children}
    </section>
  )
}
export const Hint = ({ children }: { children: ReactNode }) => <p className="text-xs leading-relaxed text-white/50">{children}</p>
