import { useEffect, useMemo, useState } from 'react'
import * as THREE from 'three'
import { Camera, Circle, Download, Eye, EyeOff, Footprints, Locate, RotateCcw, RotateCw, Square, Trash2, Copy, Pencil } from 'lucide-react'
import { useViewer } from '../store/viewerStore'
import { LIGHTING_PRESETS } from '../config/lighting'
import { COLOR_PALETTE, FINISH_PRESETS } from '../config/designPresets'
import { authoredViews, roomView, standardViews } from '../lib/cameraViews'
import { originalOf } from '../lib/materialOverrides'
import { fmtTime } from '../lib/sceneIndex'
import { CanvasRecorder, download, supportedVideoTypes } from '../lib/recorder'
import { shareUrl } from '../lib/share'
import { camState } from '../lib/camState'
import { walkSpawn } from '../three/WalkController'
import type { MatOverride } from '../types'
import { Hint, Section, Slider, Toggle, beginEdit, liveDesign } from './kit'

/* ------------------------------------------------------------------ Overview */
export function OverviewPanel() {
  const { property, index } = useViewer()
  const design = useViewer((s) => s.design)
  const toast = useViewer((s) => s.toast)
  return (
    <>
      <Section title="Property">
        <h2 className="text-lg font-semibold">{property.name}</h2>
        <p className="text-sm text-accent">{property.tagline}</p>
        <p className="mt-2 text-sm leading-relaxed text-white/70">{property.description}</p>
      </Section>
      <Section title="Facts">
        <dl className="grid grid-cols-2 gap-x-3 gap-y-1 text-sm">
          {Object.entries(property.facts).map(([k, v]) => (<div key={k} className="contents"><dt className="text-white/45">{k}</dt><dd>{v}</dd></div>))}
          {index && <><dt className="text-white/45">Model size</dt><dd>{index.stats.size.map((n) => n.toFixed(1)).join(' × ')} m</dd></>}
          {index && index.rooms.length > 0 && <><dt className="text-white/45">Mapped rooms</dt><dd>{index.rooms.length}</dd></>}
        </dl>
      </Section>
      <Section title="Share">
        <button className="btn-accent w-full" onClick={() => navigator.clipboard.writeText(shareUrl(property.id, design)).then(() => toast('Link copied (property + current design).'))}>Copy share link</button>
        <Hint>The link carries the property id and your current design (materials, lighting, visibility). Hosted public pages need the Phase 2 backend.</Hint>
      </Section>
    </>
  )
}

/* ------------------------------------------------------------------ Views & movement */
export function ViewsPanel() {
  const { index, flyTo, spin, setSpin, walkSpeed, setWalkSpeed, eyeHeight, setEyeHeight, setMode } = useViewer()
  const views = useMemo(() => (index ? standardViews(index) : []), [index])
  const authored = useMemo(() => (index ? authoredViews(index) : []), [index])
  const preset = (speed: number, dir: 1 | -1) => setSpin({ enabled: true, paused: false, speed, dir })
  const fitModel = () => { const v = views.find((x) => x.id === 'front34'); if (v) flyTo(v.position, v.target) }
  return (
    <>
      <Section title="Camera views">
        <div className="grid grid-cols-2 gap-2">
          {views.map((v) => <button key={v.id} className="btn border border-white/10" onClick={() => flyTo(v.position, v.target)}>{v.label}</button>)}
        </div>
        {authored.length > 0 && <>
          <div className="label mt-3 mb-1">Authored in Blender</div>
          <div className="grid grid-cols-2 gap-2">{authored.map((v) => <button key={v.id} className="btn border border-white/10" onClick={() => flyTo(v.position, v.target, 1.6, v.fov)}>{v.label}</button>)}</div>
        </>}
        <button className="btn mt-2 w-full border border-white/10" onClick={fitModel}><Locate size={14} /> Reset / fit model</button>
      </Section>
      <Section title="Movement">
        <div className="mb-2 flex flex-wrap gap-2">
          <button className={`chip ${spin.enabled && spin.dir === 1 && spin.speed === 1 ? 'btn-on' : ''}`} onClick={() => preset(1, 1)}>Auto spin</button>
          <button className="chip" onClick={() => preset(1, 1)}><RotateCw size={12} className="mr-1 inline" />Clockwise</button>
          <button className="chip" onClick={() => preset(1, -1)}><RotateCcw size={12} className="mr-1 inline" />Counter-clockwise</button>
          <button className="chip" onClick={() => preset(0.4, 1)}>Slow orbit</button>
          <button className="chip" onClick={() => preset(3, 1)}>Fast orbit</button>
          <button className="chip" onClick={() => setSpin({ enabled: false, paused: false })}>Manual</button>
        </div>
        <Slider label="Rotation speed" value={spin.speed} min={0.1} max={5} onChange={(v) => setSpin({ speed: v })} />
        <Toggle label="Rotation enabled" checked={spin.enabled} onChange={(b) => setSpin({ enabled: b, paused: false })} />
        {spin.enabled && spin.paused && <button className="btn-accent mt-1 w-full" onClick={() => setSpin({ paused: false })}>Resume auto-rotation</button>}
        <Hint>Auto-rotation pauses when you touch the camera; use Resume to continue.</Hint>
      </Section>
      <Section title="Walk mode">
        <button className="btn-accent w-full" onClick={() => setMode('walk')}><Footprints size={14} /> Start first-person walk</button>
        <Slider label="Walking speed (m/s)" value={walkSpeed} min={0.6} max={3} onChange={setWalkSpeed} />
        <Slider label="Eye height (m)" value={eyeHeight} min={1.55} max={1.75} step={0.01} onChange={setEyeHeight} />
      </Section>
    </>
  )
}

/* ------------------------------------------------------------------ Rooms */
export function RoomsPanel() {
  const { index, flyTo, setMode } = useViewer()
  if (!index || !index.rooms.length) return <Section title="Rooms"><Hint>No rooms are mapped for this model. Rooms are derived from named floor meshes listed in the property config; a mapping assistant is planned for Phase 2.</Hint></Section>
  const total = index.rooms.reduce((a, r) => a + r.area, 0)
  return (
    <Section title={`Rooms (${index.rooms.length})`}>
      <ul className="space-y-1.5">
        {index.rooms.map((r) => {
          const v = roomView(r)
          return (
            <li key={r.id} className="flex items-center justify-between rounded-lg border border-white/5 px-2.5 py-2">
              <div><div className="text-sm">{r.label}</div><div className="text-[11px] text-white/45">≈ {r.area} m² (bounding box)</div></div>
              <div className="flex gap-1">
                <button className="btn px-2 py-1" title="Fly to room" onClick={() => flyTo(v.position, v.target)}><Camera size={14} /></button>
                <button className="btn px-2 py-1" title="Walk here" onClick={() => { walkSpawn.value = { x: r.center[0], y: r.floorY, z: r.center[2], yaw: 0 }; setMode('walk') }}><Footprints size={14} /></button>
              </div>
            </li>
          )
        })}
      </ul>
      <Hint>Areas are estimates from floor-mesh bounding boxes ({total.toFixed(0)} m² total) - not survey-grade, and L-shaped rooms are over-estimated.</Hint>
    </Section>
  )
}

/* ------------------------------------------------------------------ Materials */
export function MaterialsPanel() {
  const { index, selected, materialEdit, setMaterialEdit, property, design, select } = useViewer()
  const [scope, setScope] = useState<'mat' | 'mesh'>('mat')
  const key = selected ? (scope === 'mat' ? 'mat:' + selected.material : 'mesh:' + selected.mesh) : ''
  const mat = selected ? index?.materials.get(selected.material) : undefined
  const orig = useMemo(() => (mat ? originalOf(mat) : {}), [mat])
  const cur: MatOverride = { ...orig, ...(design.overrides['mat:' + (selected?.material ?? '')] ?? {}), ...(scope === 'mesh' ? design.overrides[key] ?? {} : {}) }
  const users = selected ? index?.materialUsers.get(selected.material)?.length ?? 0 : 0
  const role = property.roles.find((r) => selected && r.materials.includes(selected.material))

  const set = (patch: MatOverride) => liveDesign((d) => ({ ...d, overrides: { ...d.overrides, [key]: { ...d.overrides[key], ...patch } } }))
  const reset = () => useViewer.getState().commit((d) => { const o = { ...d.overrides }; delete o[key]; return { ...d, overrides: o } })
  const applyToRole = () => {
    if (!role) return
    useViewer.getState().commit((d) => { const o = { ...d.overrides }; for (const m of role.materials) o['mat:' + m] = { ...(d.overrides[key] ?? {}) }; return { ...d, overrides: o } })
  }
  return (
    <>
      <Section title="Material edit mode">
        <Toggle label="Click a surface in the 3D view to edit it" checked={materialEdit} onChange={setMaterialEdit} />
        {!materialEdit && <Hint>Turn this on, then click any wall, floor, furniture piece... The original GLB is never modified; edits are a reversible layer.</Hint>}
      </Section>
      {selected && mat && (
        <>
          <Section title="Selected" right={<button className="chip" onClick={() => select(null)}>Clear</button>}>
            <div className="text-sm"><span className="text-white/45">Mesh </span>{selected.mesh}</div>
            <div className="text-sm"><span className="text-white/45">Material </span>{selected.material} <span className="text-white/40">({users} meshes)</span></div>
            {role && <div className="text-xs text-accent">Category: {role.label}</div>}
            <div className="mt-2 grid grid-cols-2 gap-1 rounded-lg bg-black/30 p-1 text-xs">
              <button className={`btn py-1 ${scope === 'mat' ? 'btn-on' : ''}`} onClick={() => setScope('mat')}>All {users} using it</button>
              <button className={`btn py-1 ${scope === 'mesh' ? 'btn-on' : ''}`} onClick={() => setScope('mesh')}>This mesh only</button>
            </div>
            {(mat as THREE.MeshStandardMaterial).map == null && <Hint>This material has no texture maps (flat colour). Texture scale / rotation controls need an imported texture.</Hint>}
          </Section>
          <Section title="Colour">
            <div className="mb-2 flex items-center gap-2">
              <input type="color" aria-label="Base colour" className="h-9 w-12 cursor-pointer rounded bg-transparent" value={cur.color ?? '#ffffff'} onPointerDown={beginEdit} onChange={(e) => set({ color: e.target.value })} />
              <input className="field font-mono" aria-label="Hex colour" value={cur.color ?? ''} onFocus={beginEdit} onChange={(e) => /^#[0-9a-fA-F]{6}$/.test(e.target.value) && set({ color: e.target.value })} placeholder="#rrggbb" />
            </div>
            {COLOR_PALETTE.map((g) => (
              <div key={g.label} className="mb-1.5"><div className="label mb-1">{g.label}</div>
                <div className="flex flex-wrap gap-1.5">{g.colors.map((c) => <button key={c} aria-label={c} title={c} className="h-6 w-6 rounded-full border border-white/20" style={{ background: c }} onClick={() => { beginEdit(); set({ color: c }) }} />)}</div>
              </div>
            ))}
          </Section>
          <Section title="Finish">
            <div className="mb-2 flex flex-wrap gap-1.5">{FINISH_PRESETS.map((f) => <button key={f.id} className="chip" onClick={() => { beginEdit(); set(f.o) }}>{f.label}</button>)}</div>
            <Slider label="Roughness" value={cur.roughness ?? 0.5} min={0} max={1} onStart={beginEdit} onChange={(v) => set({ roughness: v })} />
            <Slider label="Metalness" value={cur.metalness ?? 0} min={0} max={1} onStart={beginEdit} onChange={(v) => set({ metalness: v })} />
            <Slider label="Opacity" value={cur.opacity ?? 1} min={0.05} max={1} onStart={beginEdit} onChange={(v) => set({ opacity: v })} />
            <Slider label="Emissive intensity" value={cur.emissiveIntensity ?? 0} min={0} max={5} onStart={beginEdit} onChange={(v) => set({ emissiveIntensity: v })} />
          </Section>
          <Section title="Apply & reset">
            {role && <button className="btn mb-2 w-full border border-white/10" onClick={applyToRole}>Apply to whole category: {role.label}</button>}
            <button className="btn w-full border border-white/10" onClick={reset}>Restore original ({scope === 'mat' ? 'material' : 'mesh'})</button>
          </Section>
        </>
      )}
      <Section title="Whole design"><button className="btn w-full border border-white/10" onClick={() => useViewer.getState().resetDesign()}>Reset all materials, lighting & visibility</button></Section>
    </>
  )
}

/* ------------------------------------------------------------------ Lighting */
export function LightingPanel() {
  const { design, compare, setLightingPreset } = useViewer()
  const L = design.lighting
  const set = (p: Partial<typeof L>) => liveDesign((d) => ({ ...d, lighting: { ...d.lighting, ...p, preset: 'custom' } }))
  const s = <K extends keyof typeof L>(label: string, k: K, min: number, max: number, step = 0.01) => (
    <Slider label={label} value={L[k] as number} min={min} max={max} step={step} onStart={beginEdit} onChange={(v) => set({ [k]: v } as Partial<typeof L>)} />
  )
  return (
    <>
      <Section title="Presets">
        <div className="grid grid-cols-2 gap-2">{Object.entries(LIGHTING_PRESETS).map(([id, p]) => <button key={id} className={`btn border border-white/10 ${L.preset === id ? 'btn-on' : ''}`} onClick={() => setLightingPreset(id)}>{p.label}</button>)}</div>
        {compare && <Hint>Compare mode is on: showing the original lighting.</Hint>}
      </Section>
      <Section title="Sun & sky">
        {s('Sun intensity', 'sunIntensity', 0, 8)}
        {s('Sun azimuth °', 'sunAzimuth', 0, 360, 1)}
        {s('Sun elevation °', 'sunElevation', -15, 90, 1)}
        <label className="flex items-center justify-between py-1 text-sm text-white/80">Sun colour<input type="color" value={L.sunColor} onPointerDown={beginEdit} onChange={(e) => set({ sunColor: e.target.value })} /></label>
        <Toggle label="Procedural sky" checked={L.sky} onChange={(b) => { beginEdit(); set({ sky: b }) }} />
        {!L.sky && <label className="flex items-center justify-between py-1 text-sm text-white/80">Background<input type="color" value={L.background} onPointerDown={beginEdit} onChange={(e) => set({ background: e.target.value })} /></label>}
        <Toggle label="Shadows" checked={L.shadows} onChange={(b) => { beginEdit(); set({ shadows: b }) }} />
      </Section>
      <Section title="Environment & exposure">
        {s('Exposure', 'exposure', 0.3, 2.5)}
        {s('Reflection (IBL) intensity', 'envIntensity', 0, 3)}
        {s('Environment rotation °', 'envRotation', 0, 360, 1)}
      </Section>
      <Section title="Interior light group">
        <Toggle label="Chandeliers, pendants, lamps" checked={L.interiorOn} onChange={(b) => { beginEdit(); set({ interiorOn: b }) }} hint="Point lights imported from the GLB (KHR_lights_punctual)" />
        {s('Interior intensity', 'interiorIntensity', 0, 4)}
      </Section>
    </>
  )
}

/* ------------------------------------------------------------------ Visibility */
export function VisibilityPanel() {
  const { property, design, index } = useViewer()
  const toggles = property.groups.filter((g) => g.toggle)
  const setH = (id: string, hide: boolean) => useViewer.getState().commit((d) => ({ ...d, hidden: { ...d.hidden, [id]: hide } }))
  if (!property.groups.length) return <Section title="Visibility"><Hint>No semantic groups are mapped for this model, so nothing can be safely hidden. Use the Hierarchy panel to hide single objects, or add group rules to the property config.</Hint></Section>
  const web = property.groups.find((g) => g.id === 'webmerged')
  return (
    <>
      <Section title="Groups">
        {toggles.map((g) => (
          <Toggle key={g.id} label={`${g.label} (${index?.groups[g.id]?.length ?? 0})`} checked={!design.hidden[g.id]} onChange={(on) => setH(g.id, !on)} />
        ))}
        <button className="btn mt-2 w-full border border-white/10" onClick={() => useViewer.getState().commit((d) => ({ ...d, hidden: Object.fromEntries(property.groups.filter((g) => g.defaultHidden).map((g) => [g.id, true])) }))}>Restore all visibility</button>
        <div className="mt-2 flex gap-2">
          <button className="chip" onClick={() => { useViewer.getState().commit((d) => ({ ...d, hidden: { ...d.hidden, roof: true, ceiling: true } })) }}>Cutaway (no roof/ceiling)</button>
          <button className="chip" onClick={() => setH('furniture', true)}>Defurnish</button>
        </div>
      </Section>
      {web && (
        <Section title="Duplicate geometry">
          <Toggle label={`Show ${web.label} (inspection only)`} checked={!design.hidden[web.id]} onChange={(on) => setH(web.id, !on)} />
          <Hint>These pre-merged meshes duplicate the individual objects. Showing both double-renders the building.</Hint>
        </Section>
      )}
    </>
  )
}

/* ------------------------------------------------------------------ Floor plan / minimap */
export function PlanPanel({ compact = false }: { compact?: boolean }) {
  const { index, flyTo } = useViewer()
  const [, tick] = useState(0)
  useEffect(() => { const t = setInterval(() => tick((n) => n + 1), 150); return () => clearInterval(t) }, [])
  if (!index || !index.rooms.length) return <Section title="Floor plan"><Hint>Floor-plan data is unavailable (no mapped floor meshes).</Hint></Section>
  const pad = 1
  const x0 = Math.min(...index.rooms.map((r) => r.min[0])) - pad, x1 = Math.max(...index.rooms.map((r) => r.max[0])) + pad
  const z0 = Math.min(...index.rooms.map((r) => r.min[2])) - pad, z1 = Math.max(...index.rooms.map((r) => r.max[2])) + pad
  const inView = camState.x > x0 - 6 && camState.x < x1 + 6 && camState.z > z0 - 6 && camState.z < z1 + 6
  return (
    <div className={compact ? 'p-2' : 'p-4'}>
      <svg viewBox={`${x0} ${z0} ${x1 - x0} ${z1 - z0}`} className="w-full rounded-lg bg-black/30" role="img" aria-label="Floor plan">
        {index.rooms.map((r) => {
          const v = roomView(r)
          return (
            <g key={r.id} className="cursor-pointer" onClick={() => flyTo(v.position, v.target)}>
              <rect x={r.min[0]} y={r.min[2]} width={r.max[0] - r.min[0]} height={r.max[2] - r.min[2]} fill="#d9b36c22" stroke="#d9b36c88" strokeWidth={0.06} />
              <text x={r.center[0]} y={r.center[2]} fontSize={0.5} fill="#fff" textAnchor="middle" dominantBaseline="middle" pointerEvents="none">{r.label.split(' ')[0]}</text>
            </g>
          )
        })}
        {inView && <g><circle cx={camState.x} cy={camState.z} r={0.35} fill="#4cc2ff" /><line x1={camState.x} y1={camState.z} x2={camState.x + camState.dx * 1.6} y2={camState.z + camState.dz * 1.6} stroke="#4cc2ff" strokeWidth={0.15} /></g>}
        <text x={x1 - 0.4} y={z0 + 0.8} fontSize={0.7} fill="#fff9" textAnchor="end">N ↑</text>
      </svg>
      {!compact && <Hint>Generated from the model's real floor meshes. Click a room to fly there. The blue dot is the live camera. (Plan top = model -Z = Blender north.)</Hint>}
    </div>
  )
}

/* ------------------------------------------------------------------ Hierarchy */
export function HierarchyPanel() {
  const { index, select } = useViewer()
  const [q, setQ] = useState('')
  const [, force] = useState(0)
  const items = useMemo(() => (index ? index.meshes.filter((m) => m.name.toLowerCase().includes(q.toLowerCase())).slice(0, 250) : []), [index, q])
  if (!index) return null
  return (
    <Section title={`Scene hierarchy (${index.meshes.length} meshes)`}>
      <input className="field mb-2" placeholder="Search mesh name…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search meshes" />
      <ul className="max-h-[50vh] space-y-0.5 overflow-auto pr-1 text-sm">
        {items.map((m) => {
          const mat = Array.isArray(m.material) ? m.material[0] : m.material
          return (
            <li key={m.uuid} className="flex items-center justify-between rounded px-2 py-1 hover:bg-white/5">
              <button className="min-w-0 flex-1 truncate text-left" onClick={() => select({ mesh: m.name, material: ((m.userData.__origMat as THREE.Material)?.name ?? mat.name) })} title={`${m.name} · ${mat.name}`}>{m.name}<span className="ml-2 text-xs text-white/35">{mat.name}</span></button>
              <button className="btn px-1.5 py-0.5" aria-label={m.visible ? 'Hide' : 'Show'} onClick={() => { m.visible = !m.visible; force((n) => n + 1) }}>{m.visible ? <Eye size={14} /> : <EyeOff size={14} />}</button>
            </li>
          )
        })}
      </ul>
      {items.length === 250 && <Hint>Showing the first 250 matches. Selecting an item highlights it; open Materials to edit it.</Hint>}
      <Hint>Per-object visibility here is session-only and not saved in variants.</Hint>
    </Section>
  )
}

/* ------------------------------------------------------------------ Diagnostics */
export function DiagnosticsPanel() {
  const { index, property } = useViewer()
  if (!index) return null
  const st = index.stats
  return (
    <>
      <Section title="Model statistics">
        <dl className="grid grid-cols-2 gap-x-3 gap-y-1 text-sm">
          <dt className="text-white/45">Meshes</dt><dd>{st.meshes}</dd>
          <dt className="text-white/45">Triangles</dt><dd>{st.triangles.toLocaleString()}</dd>
          <dt className="text-white/45">Materials</dt><dd>{st.materials}</dd>
          <dt className="text-white/45">Textures</dt><dd>{st.textures}</dd>
          <dt className="text-white/45">Lights</dt><dd>{st.lights}</dd>
          <dt className="text-white/45">Cameras</dt><dd>{st.cameras}</dd>
          <dt className="text-white/45">Bounding box</dt><dd>{st.size.map((n) => n.toFixed(1)).join(' × ')}</dd>
          <dt className="text-white/45">Source</dt><dd className="truncate">{property.modelUrl.startsWith('blob:') ? 'local file' : property.modelUrl}</dd>
        </dl>
      </Section>
      {st.warnings.length > 0 && <Section title="Warnings"><ul className="list-disc space-y-1 pl-4 text-sm text-amber-300/90">{st.warnings.map((w) => <li key={w}>{w}</li>)}</ul></Section>}
      <Section title={`Animations (${st.clips.length})`}>
        <ul className="space-y-0.5 text-sm">{st.clips.map((c) => <li key={c.name} className="flex justify-between"><span className="truncate">{c.name}</span><span className="text-white/45">{c.duration.toFixed(1)}s</span></li>)}</ul>
      </Section>
      <Section title={`Materials (${st.materials})`}>
        <div className="flex flex-wrap gap-1.5">{[...index.materials.keys()].sort().map((m) => <span key={m} className="chip">{m} · {index.materialUsers.get(m)?.length}</span>)}</div>
      </Section>
    </>
  )
}

/* ------------------------------------------------------------------ Variants */
export function VariantsPanel() {
  const { variants, property, compare, setCompare, saveVariant, loadVariant, renameVariant, duplicateVariant, deleteVariant } = useViewer()
  const [name, setName] = useState('')
  const mine = variants.filter((v) => v.propertyId === property.id)
  return (
    <>
      <Section title="Save current design">
        <div className="flex gap-2"><input className="field" placeholder="Variant name" value={name} onChange={(e) => setName(e.target.value)} aria-label="Variant name" /><button className="btn-accent" onClick={() => { saveVariant(name); setName('') }}>Save</button></div>
        <Hint>Variants store material overrides, lighting and visibility - never a copy of the GLB. They are saved in this browser (localStorage); database persistence arrives with the Phase 2 backend.</Hint>
      </Section>
      <Section title="Compare">
        <Toggle label="Show original design (before / after)" checked={compare} onChange={setCompare} />
      </Section>
      <Section title={`Saved variants (${mine.length})`}>
        {mine.length === 0 && <Hint>No variants yet.</Hint>}
        <ul className="space-y-1.5">
          {mine.map((v) => (
            <li key={v.id} className="rounded-lg border border-white/5 p-2.5">
              <div className="flex items-center justify-between"><span className="truncate text-sm">{v.name}</span>
                <div className="flex gap-1">
                  <button className="btn px-2 py-1" title="Apply" onClick={() => loadVariant(v.id)}>Apply</button>
                  <button className="btn px-2 py-1" aria-label="Rename" onClick={() => { const n = prompt('Rename variant', v.name); if (n) renameVariant(v.id, n) }}><Pencil size={13} /></button>
                  <button className="btn px-2 py-1" aria-label="Duplicate" onClick={() => duplicateVariant(v.id)}><Copy size={13} /></button>
                  <button className="btn px-2 py-1" aria-label="Delete" onClick={() => confirm(`Delete "${v.name}"?`) && deleteVariant(v.id)}><Trash2 size={13} /></button>
                </div></div>
              <div className="text-[11px] text-white/40">{new Date(v.updatedAt).toLocaleString()} · {Object.keys(v.design.overrides).length} material edits</div>
            </li>
          ))}
        </ul>
      </Section>
    </>
  )
}

/* ------------------------------------------------------------------ Capture */
const rec = new CanvasRecorder()
export function CapturePanel() {
  const { capture, toast, index, flyTo } = useViewer()
  const types = useMemo(() => supportedVideoTypes(), [])
  const [mime, setMime] = useState(types[0] ?? '')
  const [fps, setFps] = useState(30)
  const [recording, setRecording] = useState(false)
  const [secs, setSecs] = useState(0)
  useEffect(() => { if (!recording) return; const t = setInterval(() => setSecs((s) => s + 1), 1000); return () => clearInterval(t) }, [recording])
  const shot = async (scale: number, label = 'view') => {
    const blob = await capture?.(scale)
    if (!blob) return toast('Screenshot failed (no canvas).')
    download(blob, `archvista-${label}-${Date.now()}.png`)
  }
  const hero = () => {
    const v = index && standardViews(index).find((x) => x.id === 'front34')
    if (!v) return
    flyTo(v.position, v.target, 1.2)
    setTimeout(() => shot(2, 'hero'), 1700)
  }
  const start = () => {
    const c = document.querySelector('canvas')
    if (!c || !mime) return toast('Recording is not supported in this browser.')
    rec.start(c, mime, fps)
    setSecs(0); setRecording(true)
  }
  const stop = async () => {
    const blob = await rec.stop()
    setRecording(false)
    download(blob, `archvista-tour-${Date.now()}.${mime.includes('mp4') ? 'mp4' : 'webm'}`)
  }
  return (
    <>
      <Section title="Screenshot">
        <div className="grid grid-cols-2 gap-2">
          <button className="btn border border-white/10" onClick={() => shot(1)}><Camera size={14} /> Current view</button>
          <button className="btn border border-white/10" onClick={() => shot(2)}><Download size={14} /> 2× resolution</button>
          <button className="btn-accent col-span-2" onClick={hero}>Exterior hero image</button>
        </div>
        <Hint>PNG of the live canvas. Transparent-background export is not implemented.</Hint>
      </Section>
      <Section title="Record video">
        {types.length === 0 ? <Hint>This browser does not support MediaRecorder.</Hint> : (
          <>
            <div className="mb-2 grid grid-cols-2 gap-2">
              <select className="field" value={mime} onChange={(e) => setMime(e.target.value)} aria-label="Format" disabled={recording}>{types.map((t) => <option key={t} value={t}>{t.split(';')[0]}</option>)}</select>
              <select className="field" value={fps} onChange={(e) => setFps(+e.target.value)} aria-label="Frame rate" disabled={recording}><option value={24}>24 fps</option><option value={30}>30 fps</option><option value={60}>60 fps</option></select>
            </div>
            {recording
              ? <button className="btn w-full bg-red-600/80 hover:bg-red-600" onClick={stop}><Square size={14} /> Stop & download ({fmtTime(secs)})</button>
              : <button className="btn-accent w-full" onClick={start}><Circle size={14} /> Start recording</button>}
          </>
        )}
        <Hint>Records the live canvas in real time (resolution = your window; dropped frames possible). It is not an offline Blender render. Audio narration is not implemented.</Hint>
      </Section>
    </>
  )
}
