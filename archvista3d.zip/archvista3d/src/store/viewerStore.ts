import { create } from 'zustand'
import type { Chapter, DesignState, Overrides, PropertyConfig, SceneIndex, Variant } from '../types'
import { PROPERTIES } from '../config/properties'
import { DEFAULT_LIGHTING, LIGHTING_PRESETS } from '../config/lighting'
import { DESIGN_PRESETS } from '../config/designPresets'

export type Mode = 'orbit' | 'walk' | 'tour'
export type PanelId = 'overview' | 'views' | 'rooms' | 'materials' | 'lighting' | 'visibility' | 'plan' | 'hierarchy' | 'diagnostics' | 'variants' | 'capture' | null
export type Quality = 'low' | 'balanced' | 'high'

export interface FlyReq { id: number; position: [number, number, number]; target: [number, number, number]; duration: number; fov?: number }

const VKEY = 'archvista.variants.v1'
const loadVariants = (): Variant[] => { try { return JSON.parse(localStorage.getItem(VKEY) ?? '[]') } catch { return [] } }
const saveVariants = (v: Variant[]) => { try { localStorage.setItem(VKEY, JSON.stringify(v)) } catch { /* quota */ } }

const emptyDesign = (cfg: PropertyConfig): DesignState => ({
  overrides: {},
  lighting: { ...DEFAULT_LIGHTING },
  hidden: Object.fromEntries(cfg.groups.filter((g) => g.defaultHidden).map((g) => [g.id, true])),
})

interface State {
  // property
  property: PropertyConfig
  setProperty: (p: PropertyConfig) => void
  index: SceneIndex | null
  setIndex: (i: SceneIndex | null) => void
  // ui
  mode: Mode
  setMode: (m: Mode) => void
  panel: PanelId
  setPanel: (p: PanelId) => void
  presetsOpen: boolean
  setPresetsOpen: (b: boolean) => void
  quality: Quality
  setQuality: (q: Quality) => void
  notice: string | null
  toast: (s: string) => void
  // camera
  fly: FlyReq | null
  flyTo: (position: [number, number, number], target: [number, number, number], duration?: number, fov?: number) => void
  spin: { enabled: boolean; speed: number; dir: 1 | -1; paused: boolean }
  setSpin: (s: Partial<State['spin']>) => void
  walkSpeed: number
  setWalkSpeed: (n: number) => void
  eyeHeight: number
  setEyeHeight: (n: number) => void
  // tour
  tour: { playing: boolean; time: number; duration: number; speed: number; chapters: Chapter[]; seek: number | null }
  setTour: (t: Partial<State['tour']>) => void
  // design
  design: DesignState
  past: DesignState[]
  future: DesignState[]
  commit: (next: DesignState | ((d: DesignState) => DesignState)) => void
  undo: () => void
  redo: () => void
  resetDesign: () => void
  applyPreset: (id: string) => void
  setLightingPreset: (id: string) => void
  compare: boolean
  setCompare: (b: boolean) => void
  // selection
  materialEdit: boolean
  setMaterialEdit: (b: boolean) => void
  selected: { mesh: string; material: string } | null
  select: (s: State['selected']) => void
  hover: string | null
  setHover: (s: string | null) => void
  // variants
  variants: Variant[]
  saveVariant: (name: string) => void
  loadVariant: (id: string) => void
  renameVariant: (id: string, name: string) => void
  duplicateVariant: (id: string) => void
  deleteVariant: (id: string) => void
  // capture api (registered by the canvas)
  capture: ((scale: number) => Promise<Blob | null>) | null
  setCapture: (f: State['capture']) => void
}

export const useViewer = create<State>((set, get) => ({
  property: PROPERTIES[0],
  setProperty: (p) =>
    set({
      property: p, index: null, mode: 'orbit', panel: 'overview', selected: null, materialEdit: false, fly: null, compare: false,
      design: emptyDesign(p), past: [], future: [], tour: { playing: false, time: 0, duration: 0, speed: 1, chapters: [], seek: null },
      spin: { enabled: false, speed: 1, dir: 1, paused: false },
    }),
  index: null,
  setIndex: (index) => set({ index }),

  mode: 'orbit',
  setMode: (mode) => set((s) => ({ mode, tour: { ...s.tour, playing: mode === 'tour' ? s.tour.playing : false }, spin: { ...s.spin, enabled: mode === 'orbit' ? s.spin.enabled : false } })),
  panel: 'overview',
  setPanel: (panel) => set((s) => ({ panel: s.panel === panel ? null : panel })),
  presetsOpen: false,
  setPresetsOpen: (presetsOpen) => set({ presetsOpen }),
  quality: 'balanced',
  setQuality: (quality) => set({ quality }),
  notice: null,
  toast: (notice) => { set({ notice }); setTimeout(() => get().notice === notice && set({ notice: null }), 3200) },

  fly: null,
  flyTo: (position, target, duration = 1.6, fov) => set((s) => ({ fly: { id: (s.fly?.id ?? 0) + 1, position, target, duration, fov }, mode: s.mode === 'tour' || s.mode === 'walk' ? 'orbit' : s.mode })),
  spin: { enabled: false, speed: 1, dir: 1, paused: false },
  setSpin: (p) => set((s) => ({ spin: { ...s.spin, ...p }, mode: p.enabled ? 'orbit' : s.mode })),
  walkSpeed: 1.5,
  setWalkSpeed: (walkSpeed) => set({ walkSpeed }),
  eyeHeight: 1.65,
  setEyeHeight: (eyeHeight) => set({ eyeHeight }),

  tour: { playing: false, time: 0, duration: 0, speed: 1, chapters: [], seek: null },
  setTour: (t) => set((s) => ({ tour: { ...s.tour, ...t } })),

  design: emptyDesign(PROPERTIES[0]),
  past: [],
  future: [],
  commit: (next) => set((s) => {
    const n = typeof next === 'function' ? next(s.design) : next
    return { design: n, past: [...s.past.slice(-49), s.design], future: [] }
  }),
  undo: () => set((s) => (s.past.length ? { design: s.past[s.past.length - 1], past: s.past.slice(0, -1), future: [s.design, ...s.future] } : s)),
  redo: () => set((s) => (s.future.length ? { design: s.future[0], future: s.future.slice(1), past: [...s.past, s.design] } : s)),
  resetDesign: () => get().commit(emptyDesign(get().property)),
  applyPreset: (id) => {
    const preset = DESIGN_PRESETS.find((p) => p.id === id)
    const { property } = get()
    if (!preset) return
    if (!property.roles.length) return get().toast('No material roles are mapped for this property yet (mapping assistant is Phase 2).')
    const overrides: Overrides = {}
    let applied = 0
    for (const role of property.roles) {
      const o = preset.roles[role.id]
      if (!o) continue
      for (const mat of role.materials) { overrides['mat:' + mat] = { ...o }; applied++ }
    }
    const lighting = { ...LIGHTING_PRESETS[preset.lighting].state }
    get().commit((d) => ({ ...d, overrides, lighting }))
    get().toast(`"${preset.label}" applied to ${applied} mapped materials.`)
  },
  setLightingPreset: (id) => get().commit((d) => ({ ...d, lighting: { ...LIGHTING_PRESETS[id].state } })),
  compare: false,
  setCompare: (compare) => set({ compare }),

  materialEdit: false,
  setMaterialEdit: (materialEdit) => set({ materialEdit, selected: materialEdit ? get().selected : null, panel: materialEdit ? 'materials' : get().panel }),
  selected: null,
  select: (selected) => set({ selected }),
  hover: null,
  setHover: (hover) => set({ hover }),

  variants: loadVariants(),
  saveVariant: (name) => {
    const { design, property, variants } = get()
    const now = new Date().toISOString()
    const v: Variant = { id: crypto.randomUUID(), propertyId: property.id, name: name || `Variant ${variants.length + 1}`, design: JSON.parse(JSON.stringify(design)), createdAt: now, updatedAt: now }
    const next = [...variants, v]
    saveVariants(next)
    set({ variants: next })
    get().toast(`Saved "${v.name}"`)
  },
  loadVariant: (id) => {
    const v = get().variants.find((x) => x.id === id)
    if (v) get().commit(JSON.parse(JSON.stringify(v.design)))
  },
  renameVariant: (id, name) => { const next = get().variants.map((v) => (v.id === id ? { ...v, name, updatedAt: new Date().toISOString() } : v)); saveVariants(next); set({ variants: next }) },
  duplicateVariant: (id) => {
    const v = get().variants.find((x) => x.id === id)
    if (!v) return
    const now = new Date().toISOString()
    const next = [...get().variants, { ...JSON.parse(JSON.stringify(v)), id: crypto.randomUUID(), name: v.name + ' copy', createdAt: now, updatedAt: now }]
    saveVariants(next); set({ variants: next })
  },
  deleteVariant: (id) => { const next = get().variants.filter((v) => v.id !== id); saveVariants(next); set({ variants: next }) },

  capture: null,
  setCapture: (capture) => set({ capture }),
}))
