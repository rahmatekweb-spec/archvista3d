import type * as THREE from 'three'

/** Names/regexes (tested against glTF node names) that define a semantic group. */
export interface GroupRule {
  id: string
  label: string
  patterns: string[]
  /** hide on load (e.g. duplicated merged geometry) */
  defaultHidden?: boolean
  /** shown in the Visibility panel */
  toggle?: boolean
}

export interface RoomDef {
  id: string
  label: string
  /** floor mesh node names whose union bounding box defines the room footprint */
  floorNodes: string[]
}

export interface MaterialRole {
  id: string
  label: string
  /** glTF material names that fill the role */
  materials: string[]
}

export interface PropertyConfig {
  id: string
  name: string
  tagline: string
  description: string
  modelUrl: string
  /** unit of the GLB (glTF is metres by spec) - `unitsVerified` is false until calibrated */
  unitsVerified: boolean
  groups: GroupRule[]
  rooms: RoomDef[]
  roles: MaterialRole[]
  houseNodePatterns: string[]
  collisionPatterns: string[]
  groundPatterns: string[]
  /** name of the camera node animated by the embedded tour (optional) */
  tourCamera?: string
  /** multiplier applied to imported KHR_lights_punctual (Blender exports physical cd/lux) */
  lightScale: number
  walkStart?: { position: [number, number, number]; yawDeg: number }
  facts: Record<string, string>
}

export interface MatOverride {
  color?: string
  roughness?: number
  metalness?: number
  opacity?: number
  emissive?: string
  emissiveIntensity?: number
}
/** keys: `mat:<materialName>` (every mesh using it) | `mesh:<nodeName>` (single mesh, material is cloned) */
export type Overrides = Record<string, MatOverride>

export interface LightingState {
  preset: string
  exposure: number
  sunIntensity: number
  sunAzimuth: number // degrees
  sunElevation: number // degrees
  sunColor: string
  envIntensity: number
  envRotation: number
  sky: boolean
  background: string
  interiorOn: boolean
  interiorIntensity: number
  shadows: boolean
}

export interface DesignState {
  overrides: Overrides
  lighting: LightingState
  hidden: Record<string, boolean>
}

export interface Variant {
  id: string
  propertyId: string
  name: string
  design: DesignState
  createdAt: string
  updatedAt: string
}

export interface RoomInfo {
  id: string
  label: string
  min: [number, number, number]
  max: [number, number, number]
  center: [number, number, number]
  floorY: number
  /** bounding-box area (m2) - ESTIMATE, not survey data */
  area: number
}

export interface Chapter {
  id: string
  time: number
  label: string
}

export interface SceneStats {
  meshes: number
  materials: number
  textures: number
  triangles: number
  lights: number
  cameras: number
  meshesWithoutUV: number
  size: [number, number, number]
  clips: { name: string; duration: number }[]
  warnings: string[]
}

export interface SceneIndex {
  root: THREE.Object3D
  meshes: THREE.Mesh[]
  byName: Map<string, THREE.Object3D>
  materials: Map<string, THREE.Material>
  materialUsers: Map<string, THREE.Mesh[]>
  groups: Record<string, THREE.Object3D[]>
  lights: THREE.Light[]
  cameras: THREE.Camera[]
  clips: THREE.AnimationClip[]
  houseBox: THREE.Box3
  rooms: RoomInfo[]
  stats: SceneStats
}
