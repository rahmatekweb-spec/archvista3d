// Copies the Draco decoder files that ship with three into /public/draco (offline-safe loading).
import { cpSync, existsSync, mkdirSync } from 'node:fs'
const src = 'node_modules/three/examples/jsm/libs/draco/gltf'
const dst = 'public/draco'
if (existsSync(src)) {
  mkdirSync(dst, { recursive: true })
  cpSync(src, dst, { recursive: true })
  console.log('[archvista] Draco decoder copied to', dst)
} else {
  console.warn('[archvista] three not installed yet - skipping Draco copy')
}
